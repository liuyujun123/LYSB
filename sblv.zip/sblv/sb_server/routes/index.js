var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var pool = mysql.createPool({
  host:"127.0.0.1",
  user:"root",
  password:"",
  database:"sb",
  port:3306,
  connectionLimit:5
})

//功能一:用户注册
router.post("/reg",(req,res)=>{
  var obj=req.body;
  var sql="INSERT INTO sb_user SET ?";
  pool.query(sql,[obj],(err,result)=>{
    if(err) throw err;
	  if(result.affectedRows>0){
      //res.set("Access-Control-Allow-Origin","*");
	    res.send({code:1,msg:'注册成功'});
	  }
  });
});

//功能二:查询是否已存在该用户
router.get("/isreg",(req,res)=>{
  var phone = req.query.phone;
  var sql = "SELECT uid FROM sb_user WHERE phone=?";
  pool.query(sql,[phone],(err,result)=>{
    if(err)throw err;
    if(result.length==0){
      res.send({code:1,msg:"允许注册"});
    }else{
      res.send({code:-1,msg:"该用户已注册"})
     }
  });
})

//功能三:用户登录
router.get("/login",(req,res)=>{
  var phone = req.query.phone;
  var upwd = req.query.upwd;
  var sql = "SELECT * FROM sb_user WHERE phone=? AND upwd=?";
  pool.query(sql,[phone,upwd],(err,result)=>{
    if(err)throw err;
    if(result.length==0){
      res.send({code:-1,msg:"用户名或密码有误",data:[]});
    }else{
      req.session.uid = result[0].uid;
      res.send({code:1,msg:"登录成功",data:result})
     }
  });
})

//功能x:根据sessionID查询用户
router.get("/selid",(req,res)=>{
  var uid=req.session.uid;
  var sql = "SELECT * FROM sb_user WHERE uid=?";
  pool.query(sql,[uid],(err,result)=>{
    if(err)throw err;
    if(result.length==0){
      res.send({code:-1,msg:"查询错误",data:[]});
    }else{
      res.send({code:1,msg:"查询成功",data:result})
     }
  });
});

//功能x:查询是否登录
router.get("/islogin",(req,res)=>{
    if(req.session.uid==undefined){
      res.send({code:-1,msg:"未登录"});
    }else{
      res.send({code:1,msg:"已经登录"})
     }
});
//功能x:退出登录
router.get("/logout",(req,res)=>{
  req.session.uid =undefined;
  res.send({code:1,msg:"已退出登录"})
});

//功能四:目的地组件内容
router.get("/destination",(req,res)=>{
  var sql = "SELECT * FROM sb_destination";
  pool.query(sql,(err,result)=>{
    if(err)throw err;
    res.send({code:1,msg:"目的地已查询",data:result})    
  });
})

//功能四:深度玩法内容
router.get("/play",(req,res)=>{
  var sql = "SELECT * FROM sb_play";
  pool.query(sql,(err,result)=>{
    if(err)throw err;
    res.send({code:1,msg:"玩法已查询",data:result})    
  });
})

//功能五:查询地区和ID
router.get("/area",(req,res)=>{
  var sql = "SELECT * FROM sb_area";
  pool.query(sql,(err,result)=>{
    if(err)throw err;
    res.send({code:1,msg:"地区已查询",data:result})    
  });
})

//功能六:添加行程
router.get("/cart",(req,res)=>{
  //查询session的id
  var uid = req.session.uid;
  if(!uid){
    res.send({code:-2,msg:"请登录"});
    return;
  };
  var lid=req.query.lid;
  var place=req.query.place;
  var dt=req.query.dt;
  var count=req.query.count;
  //设置订单编号did v+10位数字
  //设置随机数1-9
  var num1=Math.floor(Math.random()*10)%9+1;
  var did="v"+num1;
  //设置9位随机数0-9
  var fn=function(){
    return Math.floor(Math.random()*10)
  };
  for (var i=0;i<9;i++){
    did+=fn()
  };
  var sql = `INSERT INTO sb_cart VALUES(NULL,${uid},${lid},'${place}','${dt}',${count},'${did}')`;
  pool.query(sql,(err,result)=>{
    if(err)throw err;
    res.send({code:1,msg:"添加成功"})
  })
})

//功能七:查询行程
router.get("/findcart",(req,res)=>{
  var uid = req.session.uid;
  if(!uid){
    res.send({code:-2,msg:"请登录",data:[]});
    return;
  }
  var sql = "SELECT * FROM sb_cart WHERE uid=?";
  pool.query(sql,[uid],(err,result)=>{
      if(err)throw err;
      res.send({code:1,msg:"查询成功",data:result});
  })
});

//功能八:根据订单编号删除行程
router.get("/delm",(req,res)=>{
  var uid = req.session.uid;
  if(!uid){
    res.send({code:-2,msg:"请登录"});
    return;
  };
  var did=req.query.did;
  var sql = `DELETE FROM sb_cart WHERE did in (${did}) AND uid=?`;
  pool.query(sql,[uid],(err,result)=>{
    if(err)throw err;
    if(result.affectedRows>0){
      res.send({code:1,msg:"删除成功"});
    }else{
      res.send({code:-1,msg:"删除失败"});
    }
  });
})

// 功能九：轮播图数据
router.get("/car",(req,res)=>{
  var sql=`SELECT ftitle,fsummary,fimg FROM sb_firstpage`;
  pool.query(sql,(err,result)=>{
      if(err)throw err;
      res.send({code:1,msg:"ok",data:result})
  })
})

// 功能十：每周推荐数据
router.get("/week",(req,res)=>{
  var pno = req.query.pno;
  var ps = req.query.pageSize;
  if(!pno){pno=1}
  if(!ps){ps=19}
  var sql=`SELECT details,date,img FROM sb_recommend LIMIT ?,?`
  var offset = (pno-1)*ps;
  ps = parseInt(ps);
  pool.query(sql,[offset,ps],(err,result)=>{
    if(err)throw err;
    res.send({code:1,msg:"查询成功",data:result})
  })
})





module.exports = router;
