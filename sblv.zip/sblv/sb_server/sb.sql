SET NAMES UTF8;
DROP DATABASE IF EXISTS xz;
CREATE DATABASE sb CHARSET=UTF8;
USE sb;

#用户信息
CREATE TABLE sb_user(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  phone varCHAR(15) UNIQUE,
  upwd VARCHAR(32),
  uname VARCHAR(12) NOT NULL,
  sex BOOL NOT NULL,
  email VARCHAR(32)
);

#目的地
CREATE TABLE sb_destination(
  did INT PRIMARY KEY AUTO_INCREMENT,
  category VARCHAR(32),
  content VARCHAR(128)
);
INSERT INTO sb_destination VALUES(NULL,'亲子',"['新加坡','马尔代夫','泰国','美国','日本','新西兰','巴厘岛','英国','加拿大','秘鲁','澳大利亚','瑞士','迪拜','希腊','法国','墨西哥','南非','台湾','毛利求斯','南极','厄瓜多尔','俄罗斯','意大利']");
INSERT INTO sb_destination VALUES(NULL,'海岛',"['普吉岛','马尔代夫','巴厘岛','夏威夷','苏梅岛','毛里求斯',塞班','关岛','大溪地','塞舌尔','斐济']");
INSERT INTO sb_destination VALUES(NULL,'欧洲',"['英国','法国','希腊','意大利','德国','瑞士','挪威','西班牙','葡萄牙','奥地利','捷克','芬兰','匈牙利','瑞典','俄罗斯','荷兰','冰岛','丹麦','比利时','卢森堡','斯洛伐克','乌克兰','立陶宛','爱尔兰','摩纳哥','梵蒂冈']");
INSERT INTO sb_destination VALUES(NULL,'日本韩国',"['日本','韩国']");
INSERT INTO sb_destination VALUES(NULL,'北美洲',"['美国','加拿大','墨西哥','古巴','巴哈马']");
INSERT INTO sb_destination VALUES(NULL,'东南亚',"['泰国','新加坡','越南','柬埔寨','缅甸','马来西亚','印度尼西亚','老挝']");
INSERT INTO sb_destination VALUES(NULL,'奥斯',"['澳大利亚','新西兰','大溪地','斐济']");
INSERT INTO sb_destination VALUES(NULL,'南美洲',"['厄瓜多尔','秘鲁','智利','巴西','阿根廷','玻利维亚','哥伦比亚']");
INSERT INTO sb_destination VALUES(NULL,'南亚',"['印度','尼泊尔']");
INSERT INTO sb_destination VALUES(NULL,'中东非',"['迪拜','土耳其','以色列','南非','埃及','摩洛哥','肯尼亚','坦桑尼亚','纳米比亚','塞舌尔','毛里求斯','卡塔尔']");
INSERT INTO sb_destination VALUES(NULL,'南北极',"['阿根廷','智利','俄罗斯','芬兰','挪威','冰岛']");
INSERT INTO sb_destination VALUES(NULL,'中国台湾',"['台湾']");
INSERT INTO sb_destination VALUES(NULL,'免签',"['厄瓜多尔','迪拜','摩洛哥','巴厘岛','毛里求斯','斐济','塞班','巴哈马','塞舌尔','萨摩亚','塞尔维亚']");
INSERT INTO sb_destination VALUES(NULL,'奢华',"['南极','北极','肯尼亚','南非','摩洛哥','坦桑尼亚','纳米比亚','迪拜','加拿大']");
INSERT INTO sb_destination VALUES(NULL,'游轮',"['游轮']");

#订单详情
CREATE TABLE sb_cart(
  cid INT PRIMARY KEY AUTO_INCREMENT,
  uid INT,	       #session的id
  lid INT,             #地点id
  place VARCHAR(10),   #地点
  dt VARCHAR(20),      #时间
  count VARCHAR(10),   #人数
  did CHAR(11)         #订单号
);

#各地区信息
CREATE TABLE sb_area(
  aid INT PRIMARY KEY AUTO_INCREMENT,   #地点id
  place VARCHAR(10)   #地点
);
INSERT INTO sb_area VALUES(NULL,'日本');
INSERT INTO sb_area VALUES(NULL,'迪拜');
INSERT INTO sb_area VALUES(NULL,'新加坡');
INSERT INTO sb_area VALUES(NULL,'泰国');
INSERT INTO sb_area VALUES(NULL,'加拿大');
INSERT INTO sb_area VALUES(NULL,'澳大利亚');
INSERT INTO sb_area VALUES(NULL,'马尔代夫');
INSERT INTO sb_area VALUES(NULL,'美国');
INSERT INTO sb_area VALUES(NULL,'新西兰');
INSERT INTO sb_area VALUES(NULL,'巴厘岛');
INSERT INTO sb_area VALUES(NULL,'英国');
INSERT INTO sb_area VALUES(NULL,'秘鲁');
INSERT INTO sb_area VALUES(NULL,'瑞士');
INSERT INTO sb_area VALUES(NULL,'希腊');
INSERT INTO sb_area VALUES(NULL,'法国');
INSERT INTO sb_area VALUES(NULL,'墨西哥');
INSERT INTO sb_area VALUES(NULL,'南非');
INSERT INTO sb_area VALUES(NULL,'台湾');
INSERT INTO sb_area VALUES(NULL,'毛里求斯');
INSERT INTO sb_area VALUES(NULL,'南极');
INSERT INTO sb_area VALUES(NULL,'北极');
INSERT INTO sb_area VALUES(NULL,'厄瓜多尔');
INSERT INTO sb_area VALUES(NULL,'俄罗斯');
INSERT INTO sb_area VALUES(NULL,'意大利');
INSERT INTO sb_area VALUES(NULL,'德国');
INSERT INTO sb_area VALUES(NULL,'奥地利');
INSERT INTO sb_area VALUES(NULL,'夏威夷');
INSERT INTO sb_area VALUES(NULL,'苏梅岛');
INSERT INTO sb_area VALUES(NULL,'塞班');
INSERT INTO sb_area VALUES(NULL,'关岛');
INSERT INTO sb_area VALUES(NULL,'大溪地');
INSERT INTO sb_area VALUES(NULL,'塞舌尔');
INSERT INTO sb_area VALUES(NULL,'斐济');
INSERT INTO sb_area VALUES(NULL,'挪威');
INSERT INTO sb_area VALUES(NULL,'西班牙');
INSERT INTO sb_area VALUES(NULL,'捷克');
INSERT INTO sb_area VALUES(NULL,'芬兰');
INSERT INTO sb_area VALUES(NULL,'匈牙利');
INSERT INTO sb_area VALUES(NULL,'瑞典');
INSERT INTO sb_area VALUES(NULL,'荷兰');
INSERT INTO sb_area VALUES(NULL,'比利时');
INSERT INTO sb_area VALUES(NULL,'卢宝森');
INSERT INTO sb_area VALUES(NULL,'斯洛伐克');
INSERT INTO sb_area VALUES(NULL,'乌克兰');
INSERT INTO sb_area VALUES(NULL,'立陶宛');
INSERT INTO sb_area VALUES(NULL,'爱尔兰');
INSERT INTO sb_area VALUES(NULL,'摩洛哥');
INSERT INTO sb_area VALUES(NULL,'梵蒂冈');
INSERT INTO sb_area VALUES(NULL,'韩国');
INSERT INTO sb_area VALUES(NULL,'古巴');
INSERT INTO sb_area VALUES(NULL,'巴哈马');
INSERT INTO sb_area VALUES(NULL,'柬埔寨');
INSERT INTO sb_area VALUES(NULL,'越南');
INSERT INTO sb_area VALUES(NULL,'缅甸');
INSERT INTO sb_area VALUES(NULL,'老挝');
INSERT INTO sb_area VALUES(NULL,'马来西亚');
INSERT INTO sb_area VALUES(NULL,'印度尼西亚');
INSERT INTO sb_area VALUES(NULL,'巴西');
INSERT INTO sb_area VALUES(NULL,'阿根廷');
INSERT INTO sb_area VALUES(NULL,'玻利维亚');
INSERT INTO sb_area VALUES(NULL,'哥伦比亚');
INSERT INTO sb_area VALUES(NULL,'印度');
INSERT INTO sb_area VALUES(NULL,'尼泊尔');
INSERT INTO sb_area VALUES(NULL,'土耳其');
INSERT INTO sb_area VALUES(NULL,'以色列');
INSERT INTO sb_area VALUES(NULL,'埃及');
INSERT INTO sb_area VALUES(NULL,'肯尼亚');
INSERT INTO sb_area VALUES(NULL,'坦桑尼亚');
INSERT INTO sb_area VALUES(NULL,'纳米比亚');
INSERT INTO sb_area VALUES(NULL,'卡塔尔');
INSERT INTO sb_area VALUES(NULL,'冰岛');
INSERT INTO sb_area VALUES(NULL,'塞尔维亚');
INSERT INTO sb_area VALUES(NULL,'萨摩亚');
INSERT INTO sb_area VALUES(NULL,'游轮');


#玩法大全
CREATE TABLE sb_play(
  pid INT PRIMARY KEY AUTO_INCREMENT,   
  place VARCHAR(10),   #地点
  way VARCHAR(25),     #概要
  content VARCHAR(50)  #详情
);
INSERT INTO sb_play VALUES(NULL,'泰国','童趣探险记','泰国北部,户外学习之旅');
INSERT INTO sb_play VALUES(NULL,'坦桑尼亚','野性与文明','游猎4大国家公园,桑给巴尔岛度假');
INSERT INTO sb_play VALUES(NULL,'日本','古韵匠心','制茶 插花 品酒 禅修 尝杯 石料理');
INSERT INTO sb_play VALUES(NULL,'西班牙','穿越依比利亚','西班牙葡萄牙漫游');
INSERT INTO sb_play VALUES(NULL,'南非','野奢南非','探寻本真自然 圆梦贵族列车');
INSERT INTO sb_play VALUES(NULL,'迪拜','奢享迪拜','住奢华酒店 品云端美食');
INSERT INTO sb_play VALUES(NULL,'荷兰','情迷锡兰','海上列车 英式茶园 荷兰古堡 天空花园');
INSERT INTO sb_play VALUES(NULL,'巴哈马','逐梦巴哈马','情迷粉沙滩 流连加勒比');
INSERT INTO sb_play VALUES(NULL,'泰国','私人游艇出海','泰国南部小众海岛 享清净假期');
INSERT INTO sb_play VALUES(NULL,'俄罗斯','回溯辉煌时代','看芭蕾舞 坐莫斯科河游船 走进红场');
INSERT INTO sb_play VALUES(NULL,'不丹','佛光温暖的国度','寻梦加勒比');
INSERT INTO sb_play VALUES(NULL,'南美','追梦加勒比','走入多彩纯净的中美秘境');
INSERT INTO sb_play VALUES(NULL,'埃及','吟咏前年的史诗','尼罗河畔的前世今生');
INSERT INTO sb_play VALUES(NULL,'新西兰','呼吸纯净空气','蹦极 观星 寻万古冰川');
INSERT INTO sb_play VALUES(NULL,'澳大利亚','在南半球过暖冬','与袋鼠蹦跳 和企鹅摇摆 喂野生海豚');
INSERT INTO sb_play VALUES(NULL,'美国','你好,阳光','玩转迪士尼 私享精彩无限的亲子时光');
INSERT INTO sb_play VALUES(NULL,'日本','时尚东京','到现实中的"深夜食堂"吃粉夜宵');
INSERT INTO sb_play VALUES(NULL,'日本','探访春的气息','樱花树下喝酒 唱歌 聊天');
INSERT INTO sb_play VALUES(NULL,'美国','加州1号公路','诗情画意大瑟儿 艺术小镇卡梅尔');
INSERT INTO sb_play VALUES(NULL,'荷兰','用鲜花打开春天','安逸与疯狂');
INSERT INTO sb_play VALUES(NULL,'台湾','品文艺生活之美','诚品书店款待身心 台北故宫传统新造');
INSERT INTO sb_play VALUES(NULL,'巴西','燃烧桑巴的召唤','在亚马逊里探寻生命 在里约释放自己');
INSERT INTO sb_play VALUES(NULL,'日本','寻美归真之旅','慢游升龙道 感受浓厚地道日式风韵');
INSERT INTO sb_play VALUES(NULL,'意大利','舌尖上的意大利','松露寻味之旅 无法错过的深秋珍馐');






CREATE TABLE sb_recommend(
  rid int(11) PRIMARY KEY AUTO_INCREMENT,
  details varchar(50) NOT NULL,
  date varchar(15) NOT NULL,
  img varchar(30) NOT NULL
);
INSERT INTO sb_recommend (`rid`, `details`, `date`, `img`) VALUES
(NULL, '粉沙滩，火烈鸟，会游泳得佩奇，巴哈马连市政大楼都是粉色的', '2020.01.22', 'images/recommend/t_1.jpg'),
(NULL, '欧洲44国，春天值得去的10个都在这里', '2020.01.21', 'images/recommend/t_2.jpg'),
(NULL, '在一生要去一次的尼泊尔，落地签游东方小瑞士，20℃赏雪山', '2020.01.20', 'images/recommend/t_3.jpg'),
(NULL, '99%的人没有见过的新西兰秋天，只存在3个月的金色美梦', '2020.01.17', 'images/recommend/t_4.jpg'),
(NULL, '2020想玩点不一样的？ 拿好这份小众旅行清单', '2020.01.16', 'images/recommend/t_5.jpg'),
(NULL, '节后欧洲哪里值得去？人少景美西班牙，人人都爱它！', '2020.01.15', 'images/recommend/t_6.jpg'),
(NULL, '梦幻粉红湖，海上小火车，2020的10个浪漫旅行地（定制就送舒提啦行李箱）', '2020.01.14', 'images/recommend/t_7.jpg'),
(NULL, '2020值得去免签地，一个迪拜，满足全家人的旅行需求', '2020.01.13', 'images/recommend/t_8.jpg'),
(NULL, '在过三个月，日本樱花成海，古寺花落，现在预定刚刚好', '2020.01.10', 'images/recommend/t_9.jpg'),
(NULL, '节后出游省5000：日本、澳洲、欧洲人少景美', '2020.01.09', 'images/recommend/t_10.jpg'),
(NULL, '彩虹之国南非的正宗玩法，暖冬错过这些，小心后悔', '2020.01.08', 'images/recommend/t_11.jpg'),
(NULL, '加拿大日期限定！这6个local节日，抓住稍纵即逝的美好', '2020.01.07', 'images/recommend/t_12.jpg'),
(NULL, '毛里求斯有欧亚非风情、奇迹自然、好玩不贵，花样体验海陆空', '2020.01.06', 'images/recommend/t_13.jpg'),
(NULL, '16900元摩洛哥过春节，奢华庭院，古城漫步，星海沙哈拉', '2020.01.03', 'images/recommend/t_14.jpg'),
(NULL, '比北海道梦幻，比东京便宜，这个日本小众旅行地成亲子新宠', '2019.01.02', 'images/recommend/t_15.jpg'),
(NULL, '2020共有115天假期，这么玩才不浪费', '2020.01.02', 'images/recommend/t_16.jpg'),
(NULL, '未来两个月在云南&贵州邂逅早春，十里桃花，小桥古镇，油菜花田', '2019.12.30', 'images/recommend/t_17.jpg'),
(NULL, '亲子旅行：5个建议，孩子开心大人省心', '2019.12.27', 'images/recommend/t_18.jpg'),
(NULL, '立省7000！《只有芸知道》同款，新西兰的这些体验你值得拥有', '2019.12.26', 'images/recommend/t_19.jpg'),
(NULL, '暖冬人气的迪拜！8个满足孩子，选对酒店还免门票哦', '2019.12.26', 'images/recommend/t_20.jpg'),
(NULL, '总有一些景色，只有少数人才能见到', '2019.12.24', 'images/recommend/t_21.jpg'),
(NULL, '在人均拥有两只考拉的南美洲岛屿，过几天世外桃源的生活', '2019.12.23', 'images/recommend/t_22.jpg'),
(NULL, '日本樱花即将盛开的2个地方，还有海景温泉，沿海火车', '2019.12.19', 'images/recommend/t_23.jpg'),
(NULL, '1~3月去哪儿玩？这才是最佳旅行地', '2019.12.19', 'images/recommend/t_24.jpg'),
(NULL, '收藏！3步给父母一场完美旅行', '2019.12.18', 'images/recommend/t_25.jpg'),
(NULL, '都说印度脏乱差？去了才知道，他只有颠覆你想象的奢华', '2019.12.17', 'images/recommend/t_26.jpg'),
(NULL, '小众秘境南美和非洲，6大维度对比，看看哪适合你', '2019.12.16', 'images/recommend/t_27.jpg'),
(NULL, '如何在旺季花8000元，探索加拿大落基山下的国家公园', '2019.12.13', 'images/recommend/t_28.jpg'),
(NULL, '南澳洲的宝藏小城阿德莱德，浓缩澳洲风情，享慵懒暖冬时光', '2019.12.12', 'images/recommend/t_29.jpg'),
(NULL, '2条线路，遍历欧洲4国经典，宿极地火车，访古堡小镇', '2019.12.11', 'images/recommend/t_30.jpg'),
(NULL, '实拍：16位客人带回的一手大片，看完再出发', '2019.12.10', 'images/recommend/t_31.jpg'),
(NULL, '春节去哪？迪拜、日本、新加坡、澳洲（80%的人都在询问）', '2019.12.09', 'images/recommend/t_32.jpg'),
(NULL, '省一半票钱，看日本最美的冬天，比北海还要火', '2019.12.04', 'images/recommend/t_33.jpg'),
(NULL, '迪拜机票3499起往返(含税)，送两晚酒店，明年6月前生效', '2019.12.05', 'images/recommend/t_34.jpg'),
(NULL, '旅行顾问亲测，斯里兰卡7晚8天全纪录，游猎采茶追鲸都玩便', '2019.12.03', 'images/recommend/t_35.jpg'),
(NULL, '拒绝网红滤镜，送你一个真实的多彩之国摩洛哥！', '2019.12.02', 'images/recommend/t_36.jpg'),
(NULL, '8大避寒旅行地，这里的冬天26℃，刚刚好', '2019.11.18', 'images/recommend/t_37.jpg'),
(NULL, '早鸟|跑在加拿大的夏天，埃德蒙顿马拉松3900元/人起', '2019.5.29', 'images/recommend/t_38.jpg');



CREATE TABLE sb_firstpage (
  fid int(11) PRIMARY KEY AUTO_INCREMENT,
  ftitle varchar(50) DEFAULT NULL,
  fsummary varchar(50) DEFAULT NULL,
  fimg varchar(50) DEFAULT NULL
);
INSERT INTO sb_firstpage (`fid`, `ftitle`, `fsummary`, `fimg`) VALUES
(NULL, '初春花见·日本早樱', '游伊豆半岛，河津十里樱，热海温泉乡', 'images/firstpage/roll1.jpg'),
(NULL, '人间伊甸·毛里求斯', '七色泥土，与狮同行，红顶教堂', 'images/firstpage/roll2.jpg'),
(NULL, '梦回南洋·马来西亚', '追萤火虫，品猫山王，沙巴假日', 'images/firstpage/roll3.jpg'),
(NULL, '日本', '', 'images/firstpage/japan1.jpg'),
(NULL, '迪拜', '', 'images/firstpage/Dubai1.jpg'),
(NULL, '新加坡', '', 'images/firstpage/xjp1.jpg'),
(NULL, '泰国', '', 'images/firstpage/taiguo1.jpg'),
(NULL, '加拿大', '', 'images/firstpage/jianada1.jpg'),
(NULL, '澳大利亚', '', 'images/firstpage/aodaliya1.jpg'),
(NULL, '泰国,童趣探险记', '泰国北部, 户外学习之旅', 'images/firstpage/s_taiguo.jpg'),
(NULL, '桑坦尼亚,野性与文明并存', '游猎四大国家公园, 桑给巴尔岛度假', 'images/firstpage/s_tansangniya.jpg'),
(NULL, '日本,古韵匠心', '制茶 插花 品酒 修禅常怀石料理', 'images/firstpage/s_riben.jpg'),
(NULL, '西班牙 葡萄牙,穿越伊比利亚', '西班牙葡萄牙漫游', 'images/firstpage/s_xibanya.jpg'),
(NULL, '南非,野奢南非', '探寻本真自然 梦圆贵族列车', 'images/firstpage/s_nanfei.jpg'),
(NULL, '日 本', '溜娃宝地名古屋, 时髦小众玩法多', 'images/firstpage/l_riben.jpg'),
(NULL, '云南&贵州', '你要的国内游终于来了, 未来两个月值得玩', 'images/firstpage/l_yunnan.jpg'),
(NULL, '迪 拜', '暖冬溜娃圣地, 8个乐园承包这个假期', 'images/firstpage/l_dibai.jpg'),
(NULL, '新西兰', '烟火人间,浪漫之旅, 100%的纯净与真诚', 'images/firstpage/l_xinxilan.jpg'),
(NULL, '摩洛哥', '免签春节末班车, 奢x享庭院酒店&沙海星河', 'images/firstpage/l_monuoge.jpg'),
(NULL, '南 非', '彩虹之国的仲夏, 25℃暖阳的狂野浪漫', 'images/firstpage/l_nanfei1.jpg'),
(NULL, '亲自旅行地', '除了动物园和游乐场, 还能带孩子玩什么?', 'images/firstpage/l_qinzi.jpg'),
(NULL, '斯里兰卡', '顾问实拍亲测, 游猎采茶追鲸', 'images/firstpage/l_sililanka.jpg'),
(NULL, '海上游轮', '上有老,下有小, 全家旅行也挺好', 'images/firstpage/l_haishang.jpg'),
(NULL, '日 本', '汤池的落雪, 雪祭的花火, 越冬越浪漫', 'images/firstpage/l_riben2.jpg'),
(NULL, '极 光', '看北极光, 选加拿大还是北欧?', 'images/firstpage/l_jiguang.jpg'),
(NULL, '春节旅行地', '过年就要合家欢乐, 父母舒心, 孩子开心', 'images/firstpage/l_chunjie.jpg'),
(NULL, '日 本', '泡着温泉看红叶、雪山与大海', 'images/firstpage/l_riben.jpg'),
(NULL, '新西兰', '如果下半年只有一趟旅行, 你会选择哪里?', 'images/firstpage/l_xinxilan.jpg'),
(NULL, '马尔代夫', '住海上别墅, 享全天美食', 'images/firstpage/l_maerdaifu.jpg'),
(NULL, '阿布扎比', '阿联酋的低调首都, 石油与黄金之城', 'images/firstpage/l_abuzabi.jpg')















