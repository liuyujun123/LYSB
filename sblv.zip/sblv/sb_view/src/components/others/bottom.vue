<template>
  <mt-tabbar style="background:green" fixed>
      <mt-tab-item>
        <p @click="back">咨询旅行顾问</p>
      </mt-tab-item>
    </mt-tabbar>
</template>
<script>
export default {
  methods:{
    back(){
      this.$router.push("/")
    }
  }
}
</script>
<style  scoped>
.mint-tabbar > .mint-tab-item.is-selected{
  background: #00EE76	;
  color:azure;
  
}
p{
  font-size: 16px;
  margin:5px auto;
}

</style>