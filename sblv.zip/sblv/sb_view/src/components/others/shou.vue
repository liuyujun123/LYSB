<template>
<div>
  <div class="tit">
    <div>
      <h3>行程详情</h3>
    </div>
  </div>
  <div>
    <el-collapse v-model="activeNames" @change="handleChange">
      <el-collapse-item  name="1">
        <template slot="title">
        <font class="dfont">D1</font><h3>&nbsp; &nbsp;新加坡-鱼狮公园</h3>
      </template>
        <div class="ffont">
          <div class="rtext">
            <p>初识新加坡</p>
            <p>今日抵达新加坡，打卡新加坡地标</p> 
            <p>上午：游览【鱼尾狮公园】。半鱼半狮的鱼尾狮是新加坡的标志，在此可欣赏壮阔的滨海湾</p>
            <p>下午：前往新加坡的洋人街-【牛车水】</p>
            <p>傍晚：乘坐【飞行者摩天轮】，包揽这座城市昼夜令人目眩神迷的壮丽美景</p>
            <h2 style="color:#000;">鱼尾狮公园</h2>
            <p>半鱼半狮的鱼尾狮是新加坡的标志，鱼尾狮雕像是到访新加坡必看的景点。鱼身，象征着新加坡从小渔村谦卑起步，这个渔村当时称为 “Temasek” (淡马锡)，在古代爪哇语中意为 “海滨小镇”。狮头，则代表了新加坡最早期的名称 “Singapura” （新加坡拉），马来语中，意指 “狮城”。在鱼尾狮公园，可观赏壮阔的滨海湾，欣赏点缀在迷人天际线上的地标建筑。</p>
            <img src="http://cdn1.6renyou.cn/sight/2019_8_30_1567165864499210244.jpg@400w_267h_90q" alt="" >
          </div>
        </div>
      </el-collapse-item>
      <el-collapse-item  name="2">
        <template slot="title">
        <font class="dfont">D2</font><h3>&nbsp;&nbsp; 新加坡-环球影视城</h3>
      </template>
        <div class="ffont">
          <div class="rtext">
            <p>初识新加坡</p>
            <p>今日抵达新加坡，打卡新加坡地标</p> 
            <p>上午：游览【鱼尾狮公园】。半鱼半狮的鱼尾狮是新加坡的标志，在此可欣赏壮阔的滨海湾</p>
            <p>下午：前往新加坡的洋人街-【牛车水】</p>
            <p>傍晚：乘坐【飞行者摩天轮】，包揽这座城市昼夜令人目眩神迷的壮丽美景</p>
            <h2 style="color:#000;">牛车水</h2>
            <p>牛车水是新加坡的唐人街，从历史悠久的寺庙到时尚现代的新潮酒吧，新加坡牛车水的风貌包罗万象。牛车水美食街更是怀旧街头式用餐体验。</p>
            <img src="http://cdn1.6renyou.cn/sight/2019_9_24_1569321348363739628.jpg@400w_267h_90q" alt="" >
          </div>
        </div>
      </el-collapse-item>
      <el-collapse-item name="3">
        <template slot="title">
        <font class="dfont">D3</font><h3>&nbsp;&nbsp;&nbsp;新加坡-新山</h3>
      </template>
        <div class="ffont">
          <div class="rtext">
            <p>走入乐高的玩具世界</p>
            <p>上午：前往马来西亚新山。</p> 
            <p>下午：游玩【乐高乐园】。这里有七大主题景点，包含了让一家人尽情玩乐的70种游乐设施，几乎所有游戏都可让大人小孩尽情投入。</p>
            <h2 style="color:#000;">马来西亚乐高乐园</h2>
            <p>马来西亚乐高乐园是亚洲第一座乐高主题乐园，是为所有年龄层的家庭所设计的主题乐园，共有一万五千个乐高模型，许多可爱的大型人偶都是以乐高积木堆砌而成，采用的乐高积木超过五千万个。园内设有乐高城、小人国、探险之地、乐高王国与乐高技术园区等七个主题园区。包含了让一家人尽情玩乐的70种游乐设施、表演节目及景区。在乐高乐园，孩子们得以发挥无限的想象力，启发内心世界，以乐高积木打造自己的梦幻乐园。几乎所有游戏都可让大人小孩尽情投入，通过游戏与玩乐，增进亲子关系。</p>
            <img src="http://cdn1.6renyou.cn/sight/2018_11_14_1542160993585129189.jpg@400w_267h_90q" alt="" >
          </div>
        </div>
      </el-collapse-item>
      <el-collapse-item name="4">
        <template slot="title">
        <font class="dfont">D4</font><h3>&nbsp;&nbsp; 新加坡-乐高水世界</h3>
      </template>
        <div class="ffont">
          <div class="rtext">
            <p>尽享乐高水世界</p>
            <p>上午：继续在【乐高乐园】游玩，可前往【乐高水上乐园】。</p> 
            <p>下午：带小宝宝的家庭如有兴趣，可前往游览【Hello Kitty主题乐园】。这里有女宝宝最爱的Hello Kitty，也有男宝宝喜欢的托马斯小火车。粉嫩的世界也可满足妈妈们的少女心。</p>
            <h2 style="color:#000;">马来西亚乐高乐园</h2>
            <p>是在世界上最大及亚洲第一的乐高水上乐园。设有20个游乐设施和景点以及超过70 个乐高模型。超级推荐的景点之一是漂漂河，在那里乐高积木洒落于漂漂河上与孩子们周围一起漂流在河上；还有专为儿童设计滑水道、人造波浪游泳池和水上游乐区等。</p>
            <img src="http://cdn1.6renyou.cn/sight/2019_9_2_1567394967811982770.jpg@400w_267h_90q" alt="" >
          </div>
        </div>
      </el-collapse-item>
      <el-collapse-item name="5">
        <template slot="title">
        <font class="dfont">D5</font><h3>&nbsp;&nbsp; 新加坡-S·E·A海洋馆</h3>
      </template>
        <div class="ffont">
          <div class="rtext">
            <p>奇妙的朋友-与动物的亲密接触</p>
            <p>上午：游览亚洲最大的飞禽公园-【裕廊飞禽公园】，观看 400 个品种 5000 多只鸟。推荐参观项目：【瀑布鸟舍】、【红鹤湖和鹈鹕湾】、【飞禽奇观】、【儿童飞禽乐园】</p> 
            <p>下午：游玩【S.E.A水族馆】，窥探神奇的海洋世界。</p>
            <p>晚间：游览全球首个展示夜间动物的野生动物园-【夜间动物园】。</p>
            <h2 style="color:#000;">马来西亚乐高乐园</h2>
            <p>全球最大的海洋馆。 步入S.E.A.海洋馆，可近距离欣赏超过10万只海洋生物的千姿百态，伊氏石斑鱼和成群结队的蝠鲼。长36米、高8.3米的水族观景窗，让您能身临其境地观赏到深海栖息地展区，与鬼蝠魟、豹纹鲨等海洋生物面对面，探索神秘又迷人的海洋世界。</p>
            <img src="http://cdn1.6renyou.cn/sight/2018_11_13_1542105386918355796.jpg@400w_267h_90q" alt="" >
          </div>
        </div>
      </el-collapse-item>
    </el-collapse>
  </div>
  
</div>
</template>
<script>
  export default {
    data() {
      return {
        activeNames: ['1'],
        value:true
      };
    },
    methods: {
      handleChange(val) {
        //console.log(val);
      }
    }
  }
</script>
<style scoped>
.tit{
  display: flex;
  justify-content: space-between;
}
.dfont{
  color:#3eb166;
  font-size:40px;
}
.line{
  
  width:6%;
  float: left;
  padding:  32px 0;
  height:1000px;
}
.rtext{
  border-left:1px dashed #ccc;  /*虚线*/
  margin: 0 32px;
  float:right;
  width:85%;
  padding:0 10px ;
  color: #999999
}
.rtext img{
  width:100%;
}
.ffont{
  display: flex;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
}
</style>