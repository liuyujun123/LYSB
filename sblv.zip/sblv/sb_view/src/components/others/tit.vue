<template>
  <div id="trip_page">
    <div class="top-banner">
      <img class="logo-img" src="https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=4023940206,3623905487&fm=26&gp=0.jpg" alt="">
      <div class="main-desc">
        <div class="title"> 新加坡</div>
        <div class="text"><img src="../../assets/img/位置.png" style="width:12px;"> 4个行程 &nbsp;|&nbsp; <img src="../../assets/img/旗帜.png" style="width:12px;">13个必玩</div>
      </div>
    </div>
    
  </div>
</template>

<style scoped>
  .xdialog-body {
    padding: 0;   
  }
  /* 这个不用管，是我这边组建问题 */

  #trip_page {/*整体最外层div*/
    font-size: 12px;
  }
  .top-banner {
    position: relative;/*顶部大图片最外层  相对定位*/
  }
  .logo-img {
    display: inline-block;width: 100%;vertical-align: top; /*第二层 图片元素  宽度占满  图片显示方式为行内块元素 垂直定位 向上 */
  }
  .main-desc {
    color: #fff;position: absolute;left: 5%;bottom: 5%;/*第二层文字元素 颜色白色  绝对定位 离左以及下各距离5% */
  }
  .title{
    font-size:24px; padding-bottom:5%;
  }
</style>