<template>
  <div >
    <div class="page-head">
      <div><img src="../../assets/img/返回1.png" alt="" style="width:16px;" @click="back()"></div>
      <div class="cfont">更多必玩</div>
    </div>
  </div>
</template>
<script>
export default {
  methods:{
    back(){
      this.$router.go(-1)
    }
  }
}
</script>
<style  scoped>
.page-head{
    display:flex;/*指定布局方式为：弹性布局*/
    position:fixed;/*定位方式：固定定位 */
    z-index: 999;/* 显示元素的上方*/
    width:100%;/*填满父元素*/
    align-items: center; /*子元素垂直居中*/
    background-color: #f2f2f2;
    padding-left:7px;
    padding-right:7px;/*内边距*/
    color: aliceblue;
    height:48px;
    font-size:18px;
    
}
.cfont{
    color:#000	;margin:auto 34%;
}
</style>