<template>
  <div class="center-cont">
      <h1 class="sub-title">必玩推荐</h1>
      <div class="trip-list">
        <div class="trip-item" v-for="(item, index) in list" :key="index">
          <div class="cont-wrap">
            <img class="cont-img" :src="item.src" alt="">
            <div class="tip">新加坡</div>
          </div>
          <div class="sub-text">{{item.txt}}</div>
        </div>
      </div>
    </div>
</template>
<script>
export default {
  data () {
    return {
      list: [
        {src: 'http://img4.imgtn.bdimg.com/it/u=2588697008,407171594&fm=26&gp=0.jpg', txt: '圣淘沙名胜世界'},
        {src: 'http://img4.imgtn.bdimg.com/it/u=2588697008,407171594&fm=26&gp=0.jpg', txt: '新加坡摩天观景台'},
        {src: 'http://img4.imgtn.bdimg.com/it/u=2588697008,407171594&fm=26&gp=0.jpg', txt: '夜间野生动物园'},
        {src: 'http://img4.imgtn.bdimg.com/it/u=2588697008,407171594&fm=26&gp=0.jpg', txt: '新加坡环球影城'}
      ]
    }
  }
}
</script>
<style scoped>

  .center-cont {
    padding: 10px;   /*中部最外层 小图片部分   四个方向内边距10  文字颜色灰*/
    color: #504b4b;
  }
  .title {
    font-size: 24px;   /*中部第二层 与大图片之间的文字样式*/
  }

  .trip-list {
    display: flex;flex-wrap: wrap;justify-content: space-between;  /*中部第二层 所有小图片外层  弹性布局，自动换行 两侧对齐 中间均匀留空*/
  }
  .trip-item {
    width: 48%;margin-bottom: 10px;     /*中部第三层  v-for 循环遍历出的 子元素 占宽48%；下边距10 */
  }
  .cont-wrap {
    border-radius: 3px;overflow: hidden;position: relative;/*中部第四层 图片倒角 隐藏溢出  相对定位*/
  } 
  .cont-img {
    width: 100%;display: inline-block;vertical-align: top;/*中部第五层 具体图片 宽100%  行内块方式显示 垂直方向：向上*/
  }
  .tip {
    position: absolute;left: 0;top: 0;background-color: rgba(0, 0, 0, .4);/*中部第五层 图内具体文字 相对定位  位置左上角 背景色黑色透明 字体白色 内边距上下3 左右5*/
    color: #fff;padding: 3px 5px;
  }
  .sub-text {
    margin: 5px 0 0 0;   /* 中部第四层 图片外文字 上外边距5px */
  }
  .sub-title{
    margin-bottom:0.5rem;margin-top:0;font-size: 24px;
  }
</style>