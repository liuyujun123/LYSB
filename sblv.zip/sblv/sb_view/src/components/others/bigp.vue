<template>
  <div class="gl">
    <div>
      <div class="center-font" @click="goG">更多必玩></div>
    </div>
    <div>
      <span class="bottom-font"><b> 顾问推荐行程</b></span>
    </div>
    <div @click="gotj">
      <div class="ffont">
          <img src="../../assets/img/jp3.png" alt="">
          <div class="sfont">
            <span style="font-size:24px;font-family:微软雅黑"> 6</span>天
          </div>
        </div>
      <div class="bigfont">【曼谷芭提雅6晚7日挑战感官】泰式优雅与极限运动</div>
      <div class="smallfont">曼谷 芭提雅</div>  
      <hr>
        <div class="ffont">
          <img src="../../assets/img/jp3.png" alt="">
          <div class="sfont">
            <span style="font-size:24px;font-family:微软雅黑"> 6</span>天
          </div>
        </div>
      <div class="bigfont">【曼谷芭提雅6晚7日挑战感官】泰式优雅与极限运动</div>
      <div class="smallfont">曼谷 芭提雅</div>
      <hr>
        <div class="ffont">
          <img src="../../assets/img/jp3.png" alt="">
          <div class="sfont">
            <span style="font-size:24px;font-family:微软雅黑"> 6</span>天
          </div>
        </div>
      <div class="bigfont">【曼谷芭提雅6晚7日挑战感官】泰式优雅与极限运动</div>
      <div class="smallfont">曼谷 芭提雅</div>
      <hr>
    </div>
  </div>
</template>
<script>
export default {
  methods:{
    goG(){
      this.$router.push("/morecontent")
    },
    gotj(){
      this.$router.push("/Trip")
    }
  }
}
</script>
<style scoped>
div{
  /* 最外层div 上下自适应，左右间隙8px */
  margin:auto 8px ;  
}
img{
  width:100%;
}
.bigfont{
  font-size: 15px;
  color:#3B3B3B
}
.smallfont{
  font-size:8px;
  color:#666;
  margin-top:0.5rem;
}
*{
  text-decoration:none
}
.center-font{
  color:green; margin-left:37%;margin-bottom: 1rem;   /*更多必玩 文字居中*/
}
.bottom-font{
  font-size:18px;font-family:黑体;color: #444;
}
.ffont{
  position: relative;margin:0;
}
.sfont{
  position: absolute;bottom:5%;color:aliceblue;font-size:16px;
}
</style>