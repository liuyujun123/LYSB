<template>
    <div class="carousels">
        <img src="http://sbly.applinzi.com/images/firstpage/log.jpg" class="logimg" @click="logimg">
        <mt-swipe :auto="4000">
            <mt-swipe-item v-for="(val,i) of list" :key="i">
                <img :src="'http://sbly.applinzi.com/'+val.fimg" class="carouselaImg" @click="details('trip')" >
                <div class="title">
                    <div v-html="`${i+1}<span style='font-size:.95rem'>/${list.length}</span>`"></div>
                    <div v-text="val.ftitle"></div>
                    <div v-text="val.fsummary"></div>
                </div>
            </mt-swipe-item>
        </mt-swipe>
        <div class="btn">
            <div>
                <mt-button @click="submit(-1)"><span class="iconfont iconjia"></span> 提交需求</mt-button>
            </div>
            <div>
                <mt-button @click="submit(1)"><span class="iconfont icontubiao_fangan"></span> 我的行程方案</mt-button>
            </div>
        </div>
    </div>
</template>
<script>

export default {
    data(){
        return {
            
        }
    },
    methods:{
        details(pag){
            //跟据数据库传递的参数跳转到指定页面
            this.$router.push(`/${pag}`)
        },
        submit(num){
            //跟据提供的参数不同分别跳转到提交需求页面和行程方案页面
            if(num==-1){this.$router.go(0)}else{
                var url="islogin";
                this.axios.get(url).then(res=>{
                    if(res.data.code==-1){this.$toast("请登录")}else{
                        this.$router.push("/cart")
                    }
                })
            }
        },
        logimg(){
            //点击log跳转到6人游定制界面
            this.$router.go(0)
        }
    },
    props:["list"]
}
</script>
<style scoped>
.carousels{
    height:15rem;
    width: 100%;
}
.logimg{
    position: absolute;
    top: .7rem;
    left: .7rem;
    width: 1.7rem;
    height:1.7rem;
    border-radius:50%;
    z-index: 2;
}
.carouselaImg{
    width: 100%;
}
.title{
    position: absolute;
    top: 35%;
    left: 20%;
}
.title>div:first-child{
    font-size: 1.2rem;
}
.title>div+div{
    font-size:1rem;
    padding-top: .3rem;
}
.title>div{
    text-shadow: .1rem .1rem .1rem #000;
     color:#fff;
}
.mint-button--default {
    color: #fff;
    background-color:#71b32b;
    float: left;
    margin-top: -3.4rem;
    font-size:1rem;
    height: 2rem;
    width: 8rem;
    line-height: 2rem;

    }
.btn{
    display: flex;
    justify-content: space-between;
    padding:0 2rem;
    }
</style>