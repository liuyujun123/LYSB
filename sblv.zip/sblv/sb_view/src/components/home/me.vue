<template>
    <div class="all">
       <div class="phone">
           <router-link to="/reg" class="reg">注册</router-link>
        </div>
        <div class="textmar">
            <mt-field label="用户名" placeholder="请输入用户名" v-model="phone" :attr="{maxlength:16,autofocus:true}"  class="text"></mt-field>
            <mt-field label="密 码" placeholder="请输入密码" type="password" v-model="upwd" ></mt-field>
        </div>
        <mt-button size="large" @click="login">登录</mt-button>
    </div>
</template>
<script>
export default {
    data(){
        return {
            phone:"",
            upwd:""
        }
    },
    methods:{
        login(){
            // console.log(123)
            // 1 创建正则表达式验证用户名和密码(字母数字3-12)
            var reg1=/1[3-8]\d{9}/
            // 6-8位字母数字组合至少包含一个大写字母和数字
            var reg2=/^(?![a-z0-9]+$)(?![A-Za-z]+$)[A-Za-z0-9]{6,8}$/
            // 2 获取用户名密码
            var phone=this.phone
            var upwd=this.upwd
            // 3 验证用户名如果格式不正确提示错误信息
            if(!reg1.test(phone)){
                this.$messagebox("消息","用户名格式不正确")
                return
            }
            // 4 验证密码如果格式不正确提示错误信息
            if(!reg2.test(upwd)){
                 this.$messagebox("消息","密码格式不正确")
                 return
            }
            // 5 创建url变量保存请求服务器地址
            var url="login"
            // 6 创建obj变量保存请求的参数
            var obj={phone,upwd};
            // 7 发送ajax请求
            this.axios.get(url,{params:obj}).then(res=>{
                if(res.data.code==-1){
                    this.$messagebox("消息","用户名或者密码错误")
                }else{
                    this.$toast("登录成功")
                    location.reload()
                }
            })
            // 8 接受服务器返回结果
            // 9 如果是-1则提示用户名或者密码错误
            // 10 如果是1则跳转商品列表页product+
        }
    }
}
</script>
<style  scoped>
.all{
    margin:1rem .5rem 0 .5rem;
}
.phone{
   text-align: center;
   font-size:1.6rem;
   color:#777;
   font-weight: 500;
}
.reg{
    color:#777;
    float: right;
    font-size:1rem;
    margin-right:.8rem;
}
.mint-button::after {
    background:#04d85b;
    opacity: 0.6;
   
}
.textmar{
    margin-bottom: 1rem;}
.logimg{
    border-radius: 50%;
    width:2rem;
}
.mint-cell-wrapper {
    color:#333;
    /* 注册文字样式 */
}


</style>