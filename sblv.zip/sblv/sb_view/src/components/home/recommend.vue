<template>
    <div @click="locatimg($event,'/linggan')" class="contain">
        <div class="title">每周推荐</div>
        <div style="height:100%" id="scr">
            <div class="fire" v-for="(item,i) of list" :key="i">
                <img :src="`http://sbly.applinzi.com/`+item.img">
                <div class="detfont" v-text="item.details"></div>
                <div v-text="item.date"></div>
            </div>
        </div>
        <div class="last">
            没有更多了哦
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            list:[],
            pno:0
            }
    },
    created(){
        this.loadMore()
    },
     mounted() {
    window.addEventListener("scroll", this.scrollBottom, true);
},
    methods:{
        loadMore(){
            // 发送ajax请求获取数据
               this.pno++
             let obj={pno:this.pno,pageSize:19}
            this.axios.get("week",{params:obj}).then(res=>{
                this.list=this.list.concat(res.data.data);
            })
        },
        locatimg(e,n){
        if(e.target.nodeName=="IMG"){
            this.$router.push(n)
        }

    },
    scrollBottom() {
    // 滚动到页面底部时
    var el = document.getElementById("scr");
    if(!el){
        var windowHeight = window.screen.height;
        var scrollTop =document.documentElement.scrollTop || document.body.scrollTop;
        var toBottom = 10 - windowHeight - scrollTop;
        if (toBottom<10 && !this.finished && !this.loading) {
        this.loading = true;
        // 请求的数据未加载完成时
        this.loadMore();
        //  this.loading = false;
        }
    }
}
    },
   
}
</script>
<style scoped>
.contain{
  overflow: scroll;
  height: 2000px;
}
.fire{
    margin:.8rem .5rem ;
    border-bottom: 1px solid #ccc;
}
.title{
    text-align: center;
    padding:.5rem 0;
    border-bottom: 1px solid #ccc;
}
img{
    width:100%;
    height:100%;
    border-radius: .3rem;
}
.detfont{
    font-size: .9rem;
    padding:.3rem 0;
}
.detfont+div{
    display: inline-block;
    font-size:.7rem;
    padding:.3rem .5rem .3rem .5rem;
    background-color: #dedede;
    border-radius:1.5rem;
    color:#777;
    margin-bottom: .8rem;
}
.last{
    text-align: center;
    padding: .2rem 0 1rem 0;
    font-size: .9rem;
}
</style>