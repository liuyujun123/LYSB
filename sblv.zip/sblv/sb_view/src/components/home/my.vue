<template>
    <div class="cart">
        <div class="title">我的</div>
        <div class="info">
            <div class="cartimg">
                <img src="../../assets/cart.png">
            </div>
            <!-- 个人信息 -->
            <div class="myinfo">
                <div>{{list.uname}}</div>
                <div>{{list.phone}}</div>
            </div>
            <!-- ------- -->
            <div class="run">
                <div class="runback">
                    <div class="space"></div>
                    <div class="runing">
                        <div class="overall">
                            <div class="iconfont iconlvhang-copy-copy-copy"></div>
                            <div>定制中的行程</div>
                        </div>
                        <div class="router" @click="path">全部行程 ></div>
                    </div>
                    <div class="space"></div>
                </div>
                <div>
                    <div class="overall">
                        <div class="iconfont iconjijin"></div>
                        <div>我的旅游基金</div>
                    </div>
                    <div>0元 ></div>
                </div>
                <div>
                    <div class="overall">
                        <div class="iconfont iconcoupon"></div>
                        <div class="get">成为会员即可领取60元旅游基金</div>
                    </div>
                    <div><button >领取</button></div>
                </div>
            </div>
            <div class="more"><span>更多记录</span></div>
            <mt-button size="large" @click="submit" class="submit">提交新的需求</mt-button>
            <mt-button size="large" @click="logout" class="submit">退出登录</mt-button>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            list:{}
        }
    },
    methods:{
        path(){
            // 点击全部行程查看行程详情
            this.$router.push("/cart")
        },
        submit(){
            // 点击提交新需要跳转到提交需求组件
        },
        loadmore(){
            var url="selid";
            this.axios.get(url).then(res=>{
               this.list=res.data.data[0]
            })
        },
        logout(){
            var url="logout";
            this.axios.get(url).then(res=>{
                this.$router.go(0);
            })
        }
    },
    created(){
        this.loadmore()
    }

}
</script>
<style  scoped>
.title{
    margin:0 auto;
    border-bottom: 1px solid #999;
    text-align: center;
    padding:.7rem 0 .7rem 0;
}
.info{
    margin:0 1rem;
}
.cartimg{
    text-align: center;
}
.myinfo{
    position: absolute;
    color: white;
    top:15rem;
    left: 9rem;
    color: green;
}
.myinfo div{
    margin-bottom: 1rem;
}
img{
width:100%;
margin:.6rem auto;
border-radius: .4rem;
}
.run>div>:last-child,.run>div>div>button{
    color:#04d85b;
}
.get{
    font-size: .7rem;
}
.run>div>div>button{
    background:transparent;
    border:1px solid #04d85b;
    font-size: .7rem;
}
.run>div:not(:first-child),.run>.runback>.runing{
    display: flex;
    justify-content: space-between;
    font-size:.8rem;
    padding: .8rem 0;
    
}
.more{
    text-align: center;
    color:#04d85b;
    font-size:.35rem;
}
.mint-button::after {
    background:#04d85b;
    opacity: 0.6;
}
.cart>>>.mint-button-text{
    font-size: 1rem;
    
}
.submit{
    margin:.7rem 0;
}
.run>.runback{
    background: #eee;
     margin:0 -1rem;;
}
.runing{
    color:#000;
    background: #fff;
     
    
}
.runing>div{
    padding:0 1rem;
}
.space{
    height: .6rem;
   
}
.router{
    color:#04d85b;
}
.overall{
    display: flex;
}
.overall>:first-child{
    width:1rem;
    height: 1rem;
    margin-right: .7rem;
    color: #04d85b;
}
</style>