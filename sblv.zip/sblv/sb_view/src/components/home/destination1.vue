<template>
    <div>
        <div class="title">
            <div class="font">目的地</div>
            <router-link to="/content" class="link">更多</router-link>
        </div>
        <div class="btn1"  @click="locat($event,'/content')">
            <mt-button>东南亚</mt-button>
            <mt-button>日本韩国</mt-button>
            <mt-button>澳新</mt-button>
            <mt-button>中东非</mt-button>
        </div>
        <div class="btn2"  @click="locat($event,'/content')">
            <mt-button>欧洲</mt-button>
            <mt-button>北美洲</mt-button>
            <mt-button>南美洲</mt-button>
            <mt-button>海岛</mt-button>
        </div>
        <div class="stateImg" @click="locat($event,'/content')">
        <div v-for="(item,i) of (list.slice(0,6))" :key="i">
            <img  :src="`http://sbly.applinzi.com/${item.fimg}`" class="locatimg">
            <div class="posimg">
                <!-- 引入iconfont 库定位矢量图 -->
                <span class="iconfont iconshan shan"></span>
                <div v-text="item.ftitle" class="posfont"></div>
            </div>
        </div>
        </div>
        <div class="title">
            <div class="font">深度策划</div>
                <router-link to="/more" class="link">更多</router-link>
        </div>
        <div class=" planimg">
            <div v-for="(item,i) of (list.slice(6))" :key="i" class="textposition" @click="cehua($event,'/cehua')">
                    <img :src="`http://sbly.applinzi.com/${item.fimg}`">
                    <div class="textpost">
                        <!-- 引入iconfont 库定位矢量图 -->
                        <span class="iconfont iconlocation2 location"></span>
                        <div v-text="item.ftitle.split(',')[0]"></div>
                    </div>
                <div v-text="item.ftitle.split(',')[1]" class="ftitle"></div>
                <div v-text="item.fsummary" class="link summary"></div>
            </div>
            <div class="find link" @click="more"><span>查看更多深度玩法</span></div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
           
        }
    },
    methods:{
        locat(e,img){
            if(e.target.nodeName=="IMG"||e.target.nodeName=="BUTTON"){
                this.$router.push(img)
            }
        },
        more(){
            this.$router.push("/more")
        },
        cehua(e,img){
            if(e.target.nodeName=="IMG"){
                this.$router.push(img)
            }
        }
    },
    props: ['list'],
}
</script>
<style scoped>
.title{
    margin-top: .5rem;;
    display: flex;
    justify-content: space-between;
}
.title~div{
    display: flex;
    justify-content: space-between;
    
}
.font{
    font-size: 1.1rem;
    font-weight: bold;
}
.font+div{
    font-size:.8rem;
}
.mint-button--default {
    font-size: .7rem;
    width: 5.2rem;
    height: 1.7rem;
    background-color: #dfdfdf;
    margin-top: .5rem ;
    color: #222;
    }  
.btn1{
    margin-top: .5rem;
}
.btn2{
    margin-bottom: .5rem;
}
.stateImg{
    width:100%;
    display: flex;
    justify-content:space-around;
    white-space: nowrap;
    overflow-y:hidden;
    overflow-x:scroll;
    margin:.4rem 0;
}
.stateImg>div{
    width:100%;
    height:100%;
    border-radius: .3rem;

}
.stateImg>div+div{
    margin-left: .5rem;
}
.link{
    text-decoration: none;
    font-size: .7rem;
    color:#444;
}
.planimg{
    width:100%;
    display: flex;
    justify-content:start;
    white-space: nowrap;
    overflow-y:hidden;
    overflow-x:scroll;
}
.planimg>img{
    width:100%;
    height:100%;
    
}
.textposition{
    position: relative;  
}
.textposition>img{
    border-radius:.3rem;
}
.textpost{
    position: absolute;
    left:0.3rem;
    bottom: 3.4rem;
    font-size: .3rem;
    color:#fff;
     display: flex;
    justify-content: start;
}
.summary{
    font-size:.6rem;
    width:120px;
   white-space: normal;
}
.location{
    color:rgba(255,255,255,.8);
    font-size: .4rem;
    margin-right: .3rem;
}
.textposition+.textposition{
    margin-left: .5rem;
}
.ftitle{
    font-size: .8rem;
    font-weight: bold;
}
.find{
    width: 7.4rem;
    height:8.125rem;
    border:1px solid #666;
    margin-left: .5rem;
    line-height: 8.125rem;
    padding:0 0.7rem 0 0.7rem;
    border-radius: .3rem;
}
.posimg{
    position: relative;;
    
}
.shan{
    font-size:2.4rem;
    background: linear-gradient(to right, rgb(234, 236, 241), blue);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    width:100px;
    position: absolute;
    bottom:0rem;
    left:0rem;
    opacity: .7;
}
 .posfont{
    position: absolute;
    bottom:.2rem;
    left:1.3rem;
    font-size: .8rem;
    color:white;
} 


</style>