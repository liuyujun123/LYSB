<template>
  <div class="contain">
    <!-- 顶部 -->
    <div class="d_top">目的地</div>
    <!-- 目的地选项 -->
    <div class="nav_content">
      <!-- 左侧 -->
      <div class="nav_left">
        <div
          class="content"
          :num="key"
          v-for="(value,key) of list"
          :key="key"
          @click="selected_left"
        >
          <div class="nullcss">{{value}}</div>
        </div>
      </div>
      <!-- 右侧 -->
      <div class="nav_right">
        <div class="content" v-for="(value,key) of row" :key="key" @click="routelink">{{value}}</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "destination",
  data() {
    return {
      list: [],
      row: []
    };
  },
  methods: {
    //左侧导航地址栏点击事件
    selected_left(e) {
      //给选项添加点中样式
      var obj = document
        .getElementsByClassName("nav_left")[0]
        .querySelectorAll(".content");
      for (var i = 0; i < obj.length; i++) {
        obj[i].className = "content";
        obj[i].firstChild.className = "nullcss";
      }
      if (e.target.className == "nullcss") {
        e.target.parentNode.className = "content bg";
        e.target.className = "nullcss content_font";
        var num = e.target.parentNode.getAttribute("num");
      } else {
        e.target.className = "content bg";
        e.target.firstChild.className = "nullcss content_font";
        var num = e.target.getAttribute("num");
      }
      //异步请求选中项的地址
      var url = "destination";
      this.axios.get(url).then(res => {
        if (res.data.code == 1) {
          this.row = res.data.data[num].content
            .slice(1, -1)
            .replace(/'/g, "")
            .split(",");
        }
      });
    },
    //点击地址跳转
    routelink() {
      this.$router.push("/content");
    },
    //页面初始化加载事件
    loadMore() {
      var url = "destination";
      this.axios.get(url).then(res => {
        if (res.data.code == 1) {
          for (var i = 0; i < res.data.data.length; i++) {
            this.list.push(res.data.data[i].category);
          }
          this.row = res.data.data[0].content
            .slice(1, -1)
            .replace(/'/g, "")
            .split(",");
        }
      });
    },
    //默认选中
    seled() {
      var obj = document.body.getElementsByClassName("nav_left")[0].children[0];
      obj.className = "content bg";
      obj.children[0].className = "nullcss content_font";
    }
  },
  created() {
    this.loadMore();
  },
  updated() {
    this.seled();
  }
};
</script>
<style scoped>
.contain {
  width: 100%;
  height: 100%;
}
.d_top {
  position: fixed;
  border-bottom: 0.15rem solid rgb(241, 240, 240);
  width: 100%;
  height: 2.7rem;
  background: rgb(250, 250, 250);
  font-size: 1rem;
  font-weight: 900;
  line-height: 1rem;
  z-index: 1;
}
.nav_content {
  position: relative;
  overflow: hidden;
  height: 39rem;
}
.nav_left {
  position: absolute;
  left: 0;
  top: 2.7rem;
  width: 6rem;
  height: 36rem;
  overflow: scroll;
  background: rgb(249, 249, 249);
  font-size: 1rem;
  font-weight: 600;
}
.nav_left .content {
  box-sizing: border-box;
  height: 3.9rem;
  padding-top: 1.5rem;
}
.bg {
  background: white;
}
.nav_left .content .content_font {
  border-left: 0.3rem solid #45c018;
  height: 1rem;
  color: #45c018;
}
.nav_right {
  position: absolute;
  top: 2.7rem;
  left: 7.5rem;
  height: 34.5rem;
  overflow: scroll;
  text-align: left;
}
.nav_right .content {
  display: inline-block;
  text-align: center;
  width: 4.5rem;
  height: 3.9rem;
  background: rgb(249, 249, 249);
  box-sizing: border-box;
  padding: auto;
  padding-top: 1.5rem;
  font-size: 1rem;
  font-weight: 600;
  margin-left: 1.5rem;
  margin-top: 1rem;
}
.nav_content::before {
  content: "";
  position: fixed;
  width: 3rem;
  height: 85%;
  display: block;
  background: white;
  top: 3rem;
  z-index: 1;
}
.nav_content::before {
  width: 3rem;
  left: 5.4rem;
}
</style>