<template>
  <div class="contain">
    <!-- 顶部 -->
    <div class="s_top">提交需求</div>
    <!-- 顶部图片 -->
    <div>
      <img :src="require('@/assets/lx.jpg')" width="100%">
    </div>
    <!-- 选择项目 -->
    <div class="content">
      <div @click="openpop">
        <mt-field label="目的地" readonly  v-model="destination"></mt-field>
      </div>
      <div @click="clickPicker">
        <mt-field label="出行日期" readonly v-model="datestart"></mt-field>
      </div>
      <mt-field label="人数"  v-model="num" type="tel" placeholder="请输入数字"></mt-field>
      <mt-button type="primary" size="normal" @click="sub">提交方案</mt-button>
      <mt-datetime-picker
        v-model="pickerValue"
        type="date"
        ref="picker"
        year-format="{value} 年"
        month-format="{value} 月"
        date-format="{value} 日"
        @confirm="handleConfirm">
      </mt-datetime-picker>

      <mt-popup v-model="popupVisible" popup-transition="popup-fade" closeOnClickModal="true" position="bottom" class="mypop">
        <mt-picker :slots="slots" @change="onValuesChange" showToolbar>
          <div class="popUp">
            <div @click="popupVisible=!popupVisible">取消</div>
            <div @click="popupVisible=!popupVisible">确定</div>
          </div>
        </mt-picker>
      </mt-popup>
    </div>
  </div>
</template>
<script>
export default {
  name: 'submission',
  data(){
    return {
      destination:"",
      datestart:"",
      num:"",
      list:[],
      pickerValue:new Date(),
      popupVisible:false,
      slots: [
        {
          flex: 1,
          values: [],
          className: 'slot1',
          textAlign: 'center',
        },
      ],
    }
  },
  methods:{
    onValuesChange(picker,values){
      this.destination=values;
      if (values[0] > values[1]){
        picker.setSlotValue(1, values[0]);
      }
    },
    sub(){
      //验证是否是正确目的地
      var lid=this.list.indexOf(this.destination.toString());
      var place=this.destination;
      var dt=this.datestart;
      var count=parseInt(this.num);
      if(lid==-1){
        this.$toast("请输入有效的目的地")
      }else if(!dt){
        this.$toast("请输入有效的日期")
      }else if(!count){
        this.$toast("请输入有效的人数")
      }else{
        lid++;
        var url="cart";
        var obj={lid,place,dt,count};
        this.axios.get(url,{params:obj}).then(res=>{
          if(res.data.code==-2){
            this.$messagebox("请登录")
          }else{
            this.$messagebox("添加成功");
            this.$router.push("/cart")
          }
        })
      }
    },
    loadmore(){
      var url="area";
      this.axios.get(url).then(res=>{
        var obj=res.data.data;
        for(var i=0;i<obj.length;i++){
          this.list[i]=obj[i].place
        };
        this.slots[0].values=this.list;
        this.slots[0].defaultIndex=9;
      })
    },
    clickPicker() {
      this.$refs.picker.open();
    },
    handleConfirm(val) {
      this.datestart=val.toLocaleDateString()
    },
    openpop(){
      this.popupVisible = true
    }
  },
  created(){
    this.loadmore()
  }
}
</script>
<style scoped>
.contain{
  position: relative;
  width: 100%;
  height: 1500px;
  background: rgb(241, 240, 240);
}
.s_top{
  position: fixed;
  border-bottom: 0.15rem solid rgb(241, 240, 240);
  width: 100%;
  height:2.8rem;
  background:rgb(250, 250, 250);
  font-size: 1rem;
  font-weight:900;
  line-height: 2.8rem;
  z-index: 1;
}
.content{
  position: absolute;
  z-index: 1;
  left: .45rem;
  top:12rem;
  width: 90%;
  height: 15rem;
  border: .03rem solid transparent;
  border-radius: 1.5rem;
  background: white;
  padding: 30px 10px;
}
.mypop{
  width: 100%;
}
.popUp{
  display: flex;
  justify-content: space-between;
  color:#26a2ff;
  padding:0 5%;
}
</style>