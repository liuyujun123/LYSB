<template>
    <div class="contain">
        <!-- 调用轮播图组件 -->
        <first-page :list="list.slice(0,3)"></first-page>
        <div class="padcontent">
        <!-- 调用目的地/深度策划组件 -->
            <destination :list="list.slice(3,14)"></destination>
            <!-- 调用旅行灵感组件 -->
            <fire :list="list.slice(14)"></fire>
        </div>
    </div>
</template>
<script>
//引入轮播图组件
import firstPage from "./firstPage"
//引入目的地/深度策划组件
import destination from "./destination1"
//引入旅行灵感组件
import fire from "./fire"

export default {
    // 注册轮播图组件
    components:{firstPage,destination,fire},
    data(){
        return {
            list:[]
        }
    },
    created(){
        //生命周期:组件创建成功
        this.carousel()
    },
    methods:{
         // 加载数据库返回的数据详细信息
        carousel(){
            this.axios.get("car").then(res=>{
                if(res.data.code==1){
                    this.list=res.data.data
                    
                }
            })
        }
    }
}
</script>
<style scoped>
.padcontent{
    margin:0 .5rem;
}
.contain{
    overflow: scroll;
    position: relative;
    height: 2000px;
}
</style>