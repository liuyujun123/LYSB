<template>
    <div @click="locatimg($event,'/linggan')">
        <div class="font">旅行灵感</div>
        <div v-for="(item,i) of list" :key="i" class="fire">
            <img :src="'http://sbly.applinzi.com/'+item.fimg" class="fireimg" >
            <div class="title">
                <div v-text="item.ftitle" class="ftitle"></div>
                <div v-text="item.fsummary"></div>
            </div>
        </div>
    </div>

</template>
<script>
export default {
    data(){
        return{}
    },
    methods:{
        locatimg(event,img){
            //采用事件委托对图片实现跳转
            if(event.target.nodeName=="IMG"){
                this.$router.push(img)
            }
        }
    },
    props:["list"]
}
</script>
<style  scoped>
.font{
    font-size: 1.1rem;
    font-weight: bold;
    margin-top:.5rem;
} 
.fire{
    margin-top:.5rem;
    position: relative;
}
.fireimg{
    width:100%;
    height:100%;
    border-radius: .3rem;
    

}
.title{
    position: absolute;
    top:35%;
    height:35%;
    left:10%;
    right: 10%;
    color: aliceblue;
    text-align: center;
}
.ftitle{
    
    text-align: center;
    width: 40%;
    border-bottom:1px solid #fff;
    margin: 0 auto;
    font-size: 1.2rem;
    text-shadow: .1rem .1rem .1rem #000;
    padding-bottom: .2rem;
   
}
.ftitle+div{
    font-size: .9rem;
    padding-top: .2rem;
}

</style>