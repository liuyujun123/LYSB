import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/cart',
    name: 'Cart',
    component: () => import('../views/Cart.vue')
  },
  {
    path: '/reg',
    name: 'Reg',
    component: () => import('../views/Reg.vue')
  },
  {
    path: '/content',
    name: 'Content',
    component: () => import('../views/Content.vue')
  },
  {
    path: '/trip',
    name: 'Trip',
    component: () => import('../views/Trip.vue')
  },
  {
    path: '/morecontent',
    name: 'Morecontent',
    component: () => import('../views/Morecontent.vue')
  },
  {
    path: '/cehua',
    name: 'Cehua',
    component: () => import('../views/Cehua.vue')
  },
  {
    path: '/linggan',
    name: 'Linggan',
    component: () => import('../views/Linggan.vue')
  },
  {
    path: '/more',
    name: 'More',
    component: () => import('../views/More.vue')
  },
]

const router = new VueRouter({
  routes
})

export default router
