<template>
     <div >
       <div class="head" >
          <span class="back1" @click="back3">&lt;</span>
         <span class="font">古韵匠心</span>
     </div>

      <!-- 图片 -->
      <div class="title11">
          <img src="../assets/cehua/001.png" alt="" class="start">
      </div>

      <!-- 内容 -->
      <div class="content03">
           <div>关西，日本古韵的所在 </div>
           <div style="margin-top:20px;">在京都禅修，品茶道的"和敬清寂"</div>
            <div>赏怀石料理的美学侘寂</div>
             <div style="margin-top:20px;">风土绝佳处，宇治茶和伏见的酒一解干渴</div>
              <div>千年有马温泉温暖身心</div>
               <div style="margin-top:20px;">插花、斟茶、酿酒都让您感悟匠心独具</div>
                <div style="margin-top:20px;">在高台寺中抄经悟道</div>
                 <div>达于道者，举手投足皆是极致</div>
      </div>
      <!-- 图片二 -->
      <div class="title11">
          <img src="../assets/cehua/002.png" alt="" class="start1">
      </div>
      <!-- 图片三 -->
      <div class="title11">
          <img src="../assets/cehua/003.png" alt="" class="start1">
      </div>
      <!-- 内容 一-->
      <div class="content02">
       <span>
           岚山是京都的标志性景观，不可不到此一游，只是同时作为历史重地，其中的众多古迹和景观有着讲不完的故事，没有向导的讲解未免有些遗憾，因此一个复古拉风的人力车便能解决问题。
        </span>
      </div>
      <!-- 内容 二-->
      <div class="content02">
       <span>
         从渡月桥出发，一路随走随停，孔武有力的车夫知道沿途各个景点的典故，为您讲解的同时还可以找到完美的拍摄角度。还会经过嵯峨野竹林，这是夏日岚山的经典景观，如果在秋天抵达，还能一睹漫山红叶,层林尽染,万千画面美不胜收。
       </span>
      </div>

      <!-- 三张小图 -->
     <div>
       <img src="../assets/cehua/004.png" class="img03">
       <img src="../assets/cehua/005.png" class="img03">
       <img src="../assets/cehua/006.png" class="img03">
     </div>
       <!-- 图片三 -->
      <div class="title11">
          <img src="../assets/cehua/007.png" alt="" class="start1" style="margin-top:30px;">
      </div>
       <!-- 内容 三-->
      <div class="content02">
       <span>
        怀石料理因起源于京都，因此称为京怀石。在日本，一餐怀石料理也不是寻常百姓都可以吃的起的，因涉及到茶道、花道、器皿、禅修、厨艺、以及四季食材等技艺和知识的融会贯通，能够制作怀石料理的厨师，一定是一位大师。
       </span>
      </div>
         <!-- 内容 四-->
      <div class="content02">
       <span>
      在吉泉，品尝米其林三星的怀石料理，某种意义上讲并不是为了吃，更重要的是欣赏厨师的技艺。主厨谷河吉巳9岁就开始接触烹饪，并且对茶道、香道、花道、古文和诗歌等日本传统文化都有研究，并将这些融入到他的料理之中。作为食客，您也需要沉浸其中，努力参悟这其中的美和禅意，如有所悟，才算不枉一次怀石料理的洗礼。
       </span>
      </div>
      <!-- 三张小图 -->
     <div>
       <img src="../assets/cehua/008.png" class="img03">
       <img src="../assets/cehua/009.png" class="img03">
       <img src="../assets/cehua/0010.png" class="img03">
     </div>
     <!-- 图片四 -->
     <div>
        <img src="../assets/cehua/0011.png" alt="" class="start1">
     </div>
        <!-- 内容 五-->
      <div class="content02">
       <span>
        茶道继承了禅宗的思想，也是禅修的一部分。您的禅修体验会由主持亲自迎接，先从抄写心经开始，有助于平静心神。之后踏入高台寺的岡林院，这里是高台寺的非公开开放区域，适合体验到茶道的“和敬清寂”。
       </span>
      </div>
         <!-- 内容 六-->
      <div class="content02">
       <span>
      在这样的环境下，您会发现大师在举手投足间轻易就可以创造出美感，再搭配上器皿，与您的沟通交流，都蕴含着禅家智慧。将内心的杂念赶走，您的茶品尝起来会更加的清香回甘。
       </span>
      </div>
        <!-- 三张小图 -->
     <div>
       <img src="../assets/cehua/0010.png" class="img03">
       <img src="../assets/cehua/0012.png" class="img03">
       <img src="../assets/cehua/0013.png" class="img03">
     </div>
       <!-- 图片五 -->
     <div>
        <img src="../assets/cehua/0014.png" alt="" class="start1">
     </div>
        <!-- 内容 六-->
      <div class="content02">
       <span>
        悟禅参道的路上，也不会让您错过花道修行。池坊流是日本花道的代表性流派，一直被公认是日本插花的本源，而您的老师是一位拥有25年插花经验的池坊流传人。
       </span>
      </div>
         <!-- 内容 七-->
      <div class="content02">
       <span>
      池坊流的作品注重花与空间的结合，简单的几个花束，不受限制的花瓶样式，组合在一起就可以营造出不同的意境，与其说是抽象的模仿山水，倒不如说是将山水自然的意境浓缩于花瓶之中，一花一世界的美感，让人惊叹大师对于自然与美的理解和创造力。
       </span>
      </div>
          <!-- 三张小图 -->
     <div>
       <img src="../assets/cehua/0015.png" class="img03">
       <img src="../assets/cehua/0016.png" class="img03">
       <img src="../assets/cehua/0017.png" class="img03">
     </div>
        <!-- 图片六 -->
     <div>
        <img src="../assets/cehua/0018.png" alt="" class="start1" style="margin-top:30px;">
     </div>
        <!-- 内容 八-->
      <div class="content02">
       <span>
       宇治是有名的茶叶产地，也是在日本茶文化历史上的茶文化中心。
       </span>
      </div>
         <!-- 内容 九-->
      <div class="content02">
       <span>
      在宇治走入500年老字号三星园抹茶工坊，即使您已体会过茶道中一碗茶的仪式，但是真正理解一碗好茶，还需要知道其滋味和制法的由来。即使是机械化发达的今天，精细的宇治抹茶研磨仍然需要依靠人工石磨，这同样是修行，为了敬一碗好茶，仍然是匠心的坚持。
       </span>
      </div>
          <!-- 三张小图 -->
     <div>
       <img src="../assets/cehua/0019.png" class="img03">
       <img src="../assets/cehua/0020.png" class="img03">
       <img src="../assets/cehua/0021.png" class="img03">
     </div>
     <!-- 图片七 -->
     <div>
        <img src="../assets/cehua/0022.png" alt="" class="start1" style="margin-top:30px;">
     </div>
       <!-- 内容 十-->
      <div class="content02">
       <span>
      月桂冠初创立于17世纪，早已成为日本清酒的代表。想要知道一款清酒如何凭借清雅高贵的味道征服人们的味蕾数百年，就需要来伏见的月桂冠清酒酒厂亲自品尝。
       </span>
      </div>
         <!-- 内容 十一-->
      <div class="content02">
       <span>
      在这里，您可以尝到由号称酒米之王“山田锦”新酿的米酒。了解酿造工艺中的精米打磨，酒醪发酵，气候、温度和水质的影响，太多的因素都是人与自然长久磨合后而做出的改变。最终出产的每一滴浊酒，都是经过步步把关，坚持百年匠心的成果。
       </span>
      </div>
          <!-- 三张小图 -->
     <div>
       <img src="../assets/cehua/0023.png" class="img03">
       <img src="../assets/cehua/0024.png" class="img03">
       <img src="../assets/cehua/0025.png" class="img03">
     </div>
     <!-- 图片八-->
     <div>
        <img src="../assets/cehua/0026.png" alt="" class="start1" style="margin-top:30px;">
     </div>
        <!-- 内容 十二-->
      <div class="content02">
       <span>
      来到神户，自然想到神户牛的美味，忍不住已经在酝酿和神户牛肉在餐桌上见面的场景，而具有千年历史的有马温泉为这样的场景增加了更加高雅舒适的体验。
       </span>
      </div>
         <!-- 内容 十三-->
      <div class="content02">
       <span>
       最神奇的是，有马温泉并不是源于火山运动，而是六百万年前的古老海水因板块运动被挤出，因此富含各种矿物质，尤其有名的是这里的碳酸泉水具有保健功效，受泡汤客人的喜爱。
       </span>
      </div>
       <!-- 内容 十四-->
      <div class="content02">
       <span>
      有马温泉所在的月光园鸿胧馆温泉旅馆，也已经有1300年历史。在此经历过千年温泉的治愈后，有酒店的主厨亲自料理美食，这样的从容与奢享，才让您有足够饱满的精神迎接美食与味蕾的碰撞。
       </span>
      </div>
            <!-- 三张小图 -->
     <div>
       <img src="../assets/cehua/0027.png" class="img03" style="margin-bottom:30px;">
       <img src="../assets/cehua/0024.png" class="img03" style="margin-bottom:30px;">
       <img src="../assets/cehua/0028.png" class="img03" style="margin-bottom:30px;">
     </div>
     <!-- 参考行程 -->
     <div class="biaoti01">
       <div class="biaoti02">参考行程</div>
       <span>Reference Trip</span>
     </div>
   
     <!-- 轮播图 -->
    
      <swipe v-model="index" :autoplayTime="timer" style="margin-bottom:50px;"  >
 <swipe-item >
   <img src="../assets/cehua/0029.png" alt="" class="start1">
 </swipe-item>
 <swipe-item >
   <img src="../assets/cehua/0030.png" alt="" class="start1">
   </swipe-item>
 <swipe-item  >
   <img src="../assets/cehua/0031.png" alt="" class="start1">
   </swipe-item>
    <swipe-item>
   <img src="../assets/cehua/0032.png" alt="" class="start1">
   </swipe-item>
    <swipe-item  >
   <img src="../assets/cehua/0033.png" alt="" class="start1">
   </swipe-item>
    <swipe-item >
   <img src="../assets/cehua/0034.png" alt="" class="start1" >
   </swipe-item>
</swipe>

   <!-- 报价 -->
       <div class="biaoti01">
       <div class="biaoti02">参考报价</div>
       <span>Reference Trip</span>
     </div>
     <div class="price">
      <div>￥1 . 9万/人</div> 
      </div>
        <div class="tixing">
          <span >最后价格以实际出行人数为准</span>
        </div>
 
    <!-- 图片 价格包含 -->
    <div>
        <img src="../assets/cehua/0035.png" alt="" class="start1">
     </div>
 
      <!-- 最后 -->
      <div class="tixing2">
          <span >以上产品最终解释权归所有</span>
        </div>
        <!-- 最后按钮 -->
        <div class="endd2" fixed>
          <button class=" Btn1">分享</button>
         <button class="Btn2" @click="Cback">免费咨询该行程</button>
       </div>
          </div>
</template>

<script>

export default {
  data () {
    return {
      index: 0 ,
      timer:5000,
      list:[],
    }
  },
   created(){
    //    保存信息
        this.loadMore();
    },
  methods:{
     Cback(){
             this.$router.push("/");
      },
       back3(){
             this.$router.push("/");
      },
         loadMore(){
            //console.log(123);
            //发送请求获取购物车数据
            //1：创建变量url保存请求服务器程序地址
            var url="area";
            //2：发送ajax请求并且获取服务器返回数据
            this.axios.get(url).then(res=>{
              var rows=this.list.concat(res.data.data);
                       this.list=rows;
                     //console.log(this.list)
            })
        }
  },
 
} 
</script>

<style scoped>

*{margin:0;padding:0;}
.app{
   display: flex; /*弹性布局*/
  flex-wrap: wrap; /*子元素换行*/
  overflow: hidden; /*溢出隐藏*/
    overflow: auto; 
    
}
  .head{
      display:flex;   /* 指定布局方式:弹性布局 */
       position: fixed; /*  固定定位 */
      z-index:999;   /*  显示元素上方 */
      width:100%;  /*  填满父元素 */
     align-items: center;  /*   子元素垂直居中 */
     background-color: #fff;
     padding-left:7px;
     padding-right:7px;
     height:48px;
     color:#000;
     font-size:18px;
     border-bottom:0.5px solid #e8e8e8;
     top:0;
  }
   .back1{
   position: absolute;
   padding-left:3%; 
  }
  .font{
   width:100%;
   text-align: center;
  }
.title11{
      width:100%;
      margin:0px;
      padding:0px;
  }
 .start{
     margin:0px;
     padding:0px;
     width:100%;
     margin-top:48px; 
 }
 .content03{
        padding: 8%;
      width: 60%;
      margin-left:13%;
      text-align: center;
      line-height: 25px;
       color: #7a7373;
 }
 .start1{
     margin:0px;
     padding:0px;
     width:100%;
   
 }
  .content02{
      width:90%;
   margin: 3%;
   padding: 3%;
   letter-spacing:1px;
   line-height: 28px;
   text-align:justify; 
   text-justify:inter-ideograph;
   color: #7a7373
 }
 .img03{
   width:30%;
   border-radius: 6px;
   margin:1%;
   margin-left:2%
 }
 .biaoti01{
    width:50%;
    text-align: center;
    margin-top:20px;
     margin-bottom:40px;
   margin-left:25%
  }
   .biaoti02{
    
     font-size:25px;
     border-bottom: 1px solid #000;
     letter-spacing:7px;
  }
  .price{
    width:100%;
   text-align: center;
   
    font-size:40px;
    color:#0d922f;
    font-style:italic;
  }
    .tixing{
    font-size:8px;
    color:#7a7373;
    width:100%;
      text-align: center;
      margin-top:20px;
       margin-bottom:40px;
  }
  .tixing2{
    font-size:8px;
    color:#7a7373;
    width:100%;
      text-align: center;
      margin-top:20px;
       margin-bottom:80px;
  }
  .endd2 .Btn1{
   height:48px;
    background: #7cdf81;
    border-radius: 20px;
    color:#fff;
   border:none;
 position: fixed;
bottom: 0;
left:2.5%;
font-size: 15px;
background-color: #7cdf81;
width:10%;

 }
  .endd2 .Btn2{
   height:48px;
    background: #7cdf81;
    border-radius: 30px;
    color:#fff;
   border:none;
 position: fixed;
 letter-spacing:4px;
bottom: 0;
right: 2.5%;
font-size: 18px;
background-color: #7cdf81;
width:80%;

 }
 
</style>