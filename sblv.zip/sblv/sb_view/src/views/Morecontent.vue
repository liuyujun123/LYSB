<template>
  <div class="top">
    <Myhead ></Myhead>
    <tit2 class="tit"></tit2>
    <tit2></tit2>
    <tit2></tit2>
    <tit2></tit2>
    <bottom></bottom>
  </div>
</template>
<script>
import bottom from "@/components/others/bottom.vue"
import tit2 from "@/components/others/tit2"
import Myhead from "@/components/others/Myhead"
export default {
  components:{
    tit2,Myhead,bottom
  },
  mounted(){
    this.submit()
  },
  methods:{
    submit(){
      var url="area";
      this.axios.get(url).then(res=>{
        console.log(res.data.data)
       })
    }
    }
}
</script>
<style scoped>

  .tit{
    padding-top:48px;
  }
.top{
  padding-bottom: 50px; /*底部导航栏空间*/
}
</style>