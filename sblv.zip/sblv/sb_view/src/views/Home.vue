<template>
  <div class="page">
    <!-- 组件内容 -->
    <mt-tab-container v-model="active">
      <mt-tab-container-item id="homepage">
        <homepage></homepage>
      </mt-tab-container-item>
      <mt-tab-container-item id="destination">
        <destination></destination>
      </mt-tab-container-item>
      <mt-tab-container-item id="submission">
        <submission></submission>
      </mt-tab-container-item>
      <mt-tab-container-item id="recommend">
        <recommend></recommend>
      </mt-tab-container-item>
      <mt-tab-container-item id="me">
        <me v-if="isTrue"></me>
        <my v-else></my>
      </mt-tab-container-item>
    </mt-tab-container>  
    <!-- 底部导航栏 -->
    <mt-tabbar v-model="active" fixed class="tabbar_h">
      <mt-tab-item id="homepage" @click.native="changeState(0)">
        <tabbarIcon :focused="clickState[0]" :selectedImage="require('@/assets/zy_selected.png')" :normalImage="require('@/assets/zy_normal.png')"></tabbarIcon>
        <span>主页</span>
      </mt-tab-item>
      <mt-tab-item id="destination" @click.native="changeState(1)">
        <tabbarIcon :focused="clickState[1]" :selectedImage="require('@/assets/mdd_selected.png')" :normalImage="require('@/assets/mdd_normal.png')"></tabbarIcon>
        <span>目的地</span>
      </mt-tab-item>
      <mt-tab-item id="submission" @click.native="changeState(2)">
        <tabbarIcon :focused="clickState[2]" :selectedImage="require('@/assets/add_selected.png')" :normalImage="require('@/assets/add_selected.png')"></tabbarIcon>
        <span>提交需求</span>
      </mt-tab-item>
      <mt-tab-item id="recommend" @click.native="changeState(3)">
        <tabbarIcon :focused="clickState[3]" :selectedImage="require('@/assets/tj_selected.png')" :normalImage="require('@/assets/tj_normal.png')"></tabbarIcon>
        <span>每周推荐</span>
      </mt-tab-item>
      <mt-tab-item id="me" @click.native="changeState(4)">
        <tabbarIcon :focused="clickState[4]" :selectedImage="require('@/assets/me_selected.png')" :normalImage="require('@/assets/me_normal.png')"></tabbarIcon>
        <span>我的</span>
      </mt-tab-item>
    </mt-tabbar>  
  </div> 
</template>
<script>
import homepage from "@/components/home/homepage"
import destination from "@/components/home/destination"
import submission from "@/components/home/submission"
import recommend from "@/components/home/recommend"
import me from "@/components/home/me"
import my from "@/components/home/my"
import tabbarIcon from "@/components/home/tabbarIcon"
export default {
  components:{tabbarIcon,homepage,destination,submission,recommend,me,my},
  data(){
    return {
      active:"homepage",
      clickState:{0:true,1:false,2:false,3:false,4:false},
      isTrue:true,
    }
  },

  methods:{
    changeState(idx){
        for(var key in this.clickState){
          if(key==idx){
            this.clickState[key]=true
            }else{
              this.clickState[key]=false
            };
        };
      },
    selUser(){
      var url="islogin";
      this.axios.get(url).then(res=>{
        if(res.data.code==1){
          this.isTrue=false
        }else{
          this.isTrue=true
        }
      })
    }
  },
  created(){
    this.selUser()
  }

  }
</script>
<style scoped>
.page,.mint-tab-container,.mint-tab-container-wrap,.mint-tab-container-item{
  height: 100%;
}
.mint-tabbar>.mint-tab-item.is-selected{
  background-color: transparent;
  color: #45c018
}
.mint-tabbar > .mint-tab-item{
  color:#999999;
}
.tabbar_h{
  height: 3rem;
}
</style>