<template>
    <div class="all">
       <div class="phone">
           <span >注册</span>
        </div>
        <div class="textmar">
            <mt-field label="电 话" placeholder="请输入合法手机号" v-model="phone" 
            :attr="{maxlength:16,autofocus:true}"  class="text"  @blur.native.capture="change"></mt-field>
            <mt-field label="密 码" placeholder="大小写字母、数字6-8位密码" type="password" v-model="upwd" ></mt-field>
             <mt-field label="确认密码" placeholder="再次输入密码" type="password" v-model="upwd1" @blur.native.capture="pwd"></mt-field>
            <mt-field label="用户名" placeholder="请输入用户名" v-model="uname" :attr="{maxlength:16}"  class="text"></mt-field>
            <div class="sex">
                <span>性 别</span>
                <label >男 <input type="radio" name="sex" v-model="sex" value="男" ></label>
                <label >女 <input type="radio" name="sex" v-model="sex" value="女"></label>
           </div>
            <mt-field label="邮 箱" placeholder="请输入邮箱" v-model="email" :attr="{maxlength:16}"  class="text"></mt-field>
        </div>
        <mt-button size="large" @click="login" >注册</mt-button>
        <router-link to="/" class="back">返回</router-link>
    </div>
</template>
<script>
export default {
    data(){
        return {
            phone:"",
            upwd:"",
            uname:"",
            sex:"",
            upwd1:"",
            email:""
        }
    },
    methods:{
        login(){
            // console.log(123)
            // 1 创建正则表达式验证用户名(字母数字3-12)
            var reg1=/1[3-8]\d{9}/
            // 密码6-8位字母数字组合至少包含一个大写字母和数字
            var reg2=/^(?![a-z0-9]+$)(?![A-Za-z]+$)[A-Za-z0-9]{6,8}$/
            // 邮箱 验证格式
            var reg3=/^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
            // 2 获取用户名密码
            var phone=this.phone
            var upwd=this.upwd
            var sex=this.sex
            var email=this.email
            // 3 验证用户名如果格式不正确提示错误信息
            if(!reg1.test(phone)){
                this.$messagebox("消息","用户名格式不正确")
                return
            }
            // 4 验证密码如果格式不正确提示错误信息
            if(!reg2.test(upwd)){
                 this.$messagebox("消息","密码格式不正确")
                 return
            }
            // 5 验证邮箱格式是否正确
            if(!reg3.test(email)){
                 this.$messagebox("消息","密码格式不正确")
                 return
            }
            if(sex="男"){
                sex=1
            }else if(sex="女"){
                sex=0
            }
            // 6 创建url变量保存请求服务器地址
            var url="reg"
            // 7 创建obj变量保存请求的参数
            var obj={"phone":phone,"upwd":upwd,"uname":this.uname,"sex":sex,"email":email};
            // 7 发送ajax请求
            this.axios.post(url,obj).then(res=>{
                console.log(res)
                if(res.data.code==-1){
                    this.$messagebox("消息","用户名或者密码错误")
                }else{
                    this.$toast("注册成功")
                    this.$router.push("/")
                }
            })
            // 8 接受服务器返回结果
            // 9 如果是-1则提示用户名或者密码错误
            // 10 如果是1则跳转商品列表页product+
            // 11 测试 152825452391 1111Qw
        },
    change(){
        var obj={phone:this.phone}
        this.axios.get("isreg",{params:obj}).then(res=>{
            if(res.data.code==-1){
              this.$messagebox("消息","用户名已存在!请登录")  
              return
            }
        })
        
    },
    pwd(){
        if(this.upwd1!=""&&this.upwd1!=this.upwd){
            this.$messagebox("消息","与第一次密码不符")  
            this.upwd1=""
            return 
        }
    }
    }
    
}
</script>
<style  scoped>
.all{
    margin:1rem .5rem 0 .5rem;
}
.phone{
   text-align: center;
   font-size:1.6rem;
   color:#777;
   font-weight: 500;
}
.mint-button::after {
    background:#04d85b;
    opacity: 0.6;
   
}
.sex{
    display: flex;
    justify-content:space-between;
    margin:.3rem 3rem .3rem 10px;
    font-size:.9rem;
}
.mint-radiolist-title{
    font-size:16px;
    /* margin-left: 2px; */
}
.textmar{
    margin-bottom: 1rem;}
.logimg{
    border-radius: 50%;
    width:2rem;
}

.textmar>>>.mint-cell-wrapper { 
    font-size:.9rem;
    /* 采用scoped穿透方式修改 */
}
label{
    color:#888;
}
.back{
  position: fixed;
  top: .5rem;
  left:0;
  text-decoration: none;
  font-size: 2rem;
  color:#8a8a8a;
}
</style>