<template>
<div class="top">
  <myhead1></myhead1>
  <div class="ltop">
    <img width="100%" src="http://b1-q.mafengwo.net/s13/M00/7E/6D/wKgEaVxvW_GAO6oZAANXWAk8iek67.jpeg">
  </div>
  <div class="radius">
    <div class="tit-font">
      <h2>【亲子度假·新加坡+明丹岛8日】明丹岛ClubMed+环球影城+国家博物馆</h2>
    </div>
    <div class="tit-time space">
      <div style="color:#71C671"><font class="middle-font">8</font>天</div>
      <div class="small-font">842人咨询过</div>
    </div>
  </div>
  <div class="tubiao">
    <div><img src="../assets/img/勾.png" alt="">量身定制</div>
    <div><img src="../assets/img/勾.png" alt="">专车专购</div>
    <div><img src="../assets/img/勾.png" alt="">私家小团</div>
  </div>
  <div class="space">
    <h4>行程亮点</h4>
    <div class="center-font">
      <p>● 城市风光+民丹岛度假，1次出游2种体验</p>
      <p>● 品美食、逛街区、看博物馆及美术馆,high玩环球影城,遇见最美狮城</p>
      <p>● 入住民丹岛ClubMed,享受一价全包的家庭时光</p>
    </div>
  </div>
  <div class="center-tubiao">
    <div><img src="../assets/img/家人.png" alt=""><p>私密旅行<br> 只和家人朋友</p></div>
    <div><img src="../assets/img/尊贵.png" alt=""><p>1对1顾问<br> 量身定制</p></div>
    <div><img src="../assets/img/安全.png" alt=""><p>7x24小时<br> 全程保障</p></div>
  </div>
  <shou>
      
  </shou>
  <bottom></bottom>
</div>
</template>
<script>
import shou from "@/components/others/shou.vue"
import bottom from "@/components/others/bottom.vue"
import myhead1 from "@/components/others/Myhead1.vue"
export default {
  components:{
    shou,bottom,myhead1
  }
}
</script>
<style scoped>
.radius{
  border-top-right-radius: 10rem
}
.space{    /*左右空隙*/
  padding: 0 15px;
  color:#4e4e4e
}
.tit-font{      /*顶部大字*/
  padding:0 15px; color:#555555	
}
.tit-time{
  display: flex;  /*上部时间 查询*/
  justify-content: space-between; /*左右对齐*/
  color:#8A8A8A
}
.small-font{
  font-size:12px
}
.middle-font{
  font-size:20px;
}
.tubiao{       /*上部小字介绍*/
  display: flex;
  justify-content: space-around;  /*环绕对齐，均有间隙*/
  font-size:14px;
  color:#828282;
  background:#FAFAFA;
  line-height: 48px;  /*垂直居中*/
  height:3rem;
  position: relative;
  margin:1rem 0;
}
.tubiao img{
  width:14px;
}
.center-font{
  font-size:13px;
}
.center-tubiao{
  display: flex;
  justify-content: space-around;  /*环绕对齐，均有间隙*/
  color:#828282;
  background:#FAFAFA;
  font-size:14px;
  height:6rem;
  position: relative;
  text-align: center;
}
.center-tubiao img{
  width:24px; margin-top:15px;
}
.center-tubiao p{
  margin:0px;
}
.top{
  padding-bottom: 50px; /*底部导航栏空间*/
}
.ltop{
  padding-top:30px;
}
</style>