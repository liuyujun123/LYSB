<template>
  <div class="page-tabbar">
    <myhead1></myhead1>
    <div class="page-wrap">
    <tit></tit>
    <tit1></tit1>
     <bigp ></bigp>
      <bottom ></bottom>
    </div>
  </div>
</template>
<script>
import tit from "@/components/others/tit.vue";
import bottom from "@/components/others/bottom.vue";
import bigp from "@/components/others/bigp.vue"
import tit1 from "@/components/others/tit1.vue"
import myhead1 from "@/components/others/Myhead1"
export default {
  components:{
    tit,bottom,bigp,tit1,myhead1
  },
  mounted(){
    this.submit()
  },
  methods:{
    submit(){
      var url="area";
      this.axios.get(url).then(res=>{
        //console.log(res.data.data)
       })
    }
    }
  }
</script>

<style  scoped>
/*最外层父元素*/
.page-tabbar{
  overflow:hidden;  /*溢出就隐藏*/
  

}
/* 内层元素 */
.page-wrap{
  overflow: auto;/*数据多出的隐藏*/
    padding-bottom: 50px; /*底部导航栏空间*/
    padding-top:30px;
}
</style>