<template>
  <div class="app">
     <div class="head" >
          <span class="back1" @click="back">&lt;</span>
         <span class="font">深度玩法</span>
        
     </div>
     <!-- 图片内容 -->
     
     <div class="title" v-for="(item,i) of list" :key="i">
     <img  src="../assets/1.jpg" alt="" class="pace" >
     <span class="span1">{{item.way}}</span>
     <span class="span2">{{item.content}}</span>
 </div>

       <div class="end">
           <h5 class="endd">没有更多内容了...</h5>
       </div>
</div>
</template>

<script>

export default {
  data(){
    return{
       list:[],
       
    }
  },
   created(){
    //    保存信息
        this.loadMore();
    },
   methods:{
    back(){  
    
       this.$router.go(-1);
      
   
    },
     loadMore(){
            //console.log(123);
            //发送请求获取购物车数据
            //1：创建变量url保存请求服务器程序地址
            var url="play";
            //2：发送ajax请求并且获取服务器返回数据
            this.axios.get(url).then(res=>{
              var rows=this.list.concat(res.data.data);
                       this.list=rows;
            })
        }
  },
}
</script>

<style scoped>
*{margin:0;padding:0;}
.app{
   display: flex; /*弹性布局*/
  flex-wrap: wrap; /*子元素换行*/
  overflow: hidden; /*溢出隐藏*/
    overflow: auto; 
}
  .head{
      display:flex;   /* 指定布局方式:弹性布局 */
       position: fixed; /*  固定定位 */
      z-index:999;   /*  显示元素上方 */
      width:100%;  /*  填满父元素 */
     align-items: center;  /*   子元素垂直居中 */
     background-color: #fff;
     padding-left:7px;
     padding-right:7px;
     height:48px;
     color:#000;
     font-size:18px;
     border-bottom:0.5px solid #e8e8e8;
  }
   .back1{
   position: absolute;
   padding-left:3%; 
  }
  .font{
   width:100%;
   text-align: center;
  }
 
  .title{
        overflow: auto; 
   width: 48%; /* 占用屏幕的一半 */
  margin: 2px 0; /*外边距 */
  padding: 2px;
  display: flex; /*子元素设置弹性布局*/
  flex-direction: column;
 
  }
 .pace{
    margin-top:38px;
    
 }
 .iimg,.pace{
   border-radius:5px ; /*圆角 */
   width:90%;
  padding-top:23px;
   margin-left:7%;
 }

 .span1{
   margin-top: 15px;
   font-size:17px;
   margin-left: 7%;
 }
 .span2{
   margin-top: 5px;
   font-size:15px;
   color:#928d8d;
 margin-left: 7%;
 }
 .end{
        display:flex;   /* 指定布局方式:弹性布局 */
      width:100%;  /*  填满父元素 */
     align-items: center;  /*   子元素垂直居中 */
 }
 .endd{
     margin-top:20px; 
     margin-bottom:20px; 
     width:100%;
   text-align: center;
   color:#acacac;
 }
</style>