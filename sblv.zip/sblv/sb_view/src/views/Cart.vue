<template>
  <div class="cart">
    <!-- 顶部 -->
    <div class="c_top">
      <span class="lt_back" @click="backTo()">&lt;</span>
      订单列表
    </div>
    <div class="selectall">
      <label>
        <input type="checkbox" v-model="isAgree" @change="selectAll">
        <span class="selectall_font">全选</span>
      </label>
    </div>
    <!-- 占位块 -->
    <div class="notcontent"></div>
    <!-- 内容 -->
    <div class="content" v-for="(val,key) of list" :key="key">
      <input type="checkbox" v-model="val.isAgree" @change="changeitem">
      <div>
        <div>{{val.place}}</div>
        <div>{{val.did}}</div>
        <div>{{val.dt}}出发</div>
        <div>{{val.count}}人</div>
      </div>
      <mt-button @click="delm(val.did,val.isAgree)" type="primary">删除</mt-button>
    </div>
    <!-- 底部 -->
    <div class="footcart" @click="goTo">提交您的旅行需求</div>
  </div>
</template>
<script>
export default {
  name: 'cart',
  data(){
    return {
      isAgree:false,
      list:[]
    }
  },
  methods:{
    loadmore(){
      setTimeout(()=>{
        var url="findcart";
        this.axios.get(url).then(res=>{
        var obj=res.data.data;
        for(var i=0;i<obj.length;i++){
          this.list[i]=obj[i];
          this.list.splice(0,0)
        };
      })
      },1000)
    },
    backTo(){
      this.$router.push("/")
    },
    goTo(){
      this.$router.push("/")
    },
    selectAll(){
      for(var val of this.list){
        val.isAgree=this.isAgree;
      }
    },
    //根据订单号删除
    delm(did,yn){
      var url="delm";
      var obj={did:`'${did}'`}
      if(yn){
        this.axios.get(url,{params:obj}).then(res=>{
          this.$toast("删除成功");
          this.$router.go(0)
        })
      }else{
        this.$toast("请选择要删除的订单");
      }
    },
    changeitem(){
      var size = this.list.length;
      var sum = 0;
      for(var val of this.list){
         if(val.isAgree)sum++;
      }
      if(size==sum){
        this.isAgree=true;
      }else{
        this.isAgree=false;
      }
    }
  },
  created(){
    this.loadmore();
  }
}
</script>
<style scoped>
.cart{
  position: relative;
  width: 100%;
  background: rgb(241, 240, 240);
  font-size: 1rem;
  font-weight:900;
}
.c_top{
  position: fixed;
  top:0;
  border-bottom: 0.15rem solid rgb(241, 240, 240);
  width: 100%;
  height:2.7rem;
  background:rgb(250, 250, 250);
  font-size: 1rem;
  font-weight:900;
  line-height: 2.9rem;
  z-index: 1;
}
.lt_back{
  position: absolute;
  left: .3rem;
  cursor: pointer;
}
.selectall{
  position: fixed;
  top:2.7rem;
  background:rgb(250, 250, 250);
  height:2.1rem;
  width: 100%;
  text-align: left;
  padding-left: 1.5rem;
  box-sizing: border-box;
  z-index: 1;
}
.selectall_font{
  position: absolute;
  right: 1.8rem;
}
.content{
  margin-top:.9rem;
  margin-left: .9rem;
  width: 90%;
  border: .1rem solid transparent;
  border-radius: .6rem;
  display: flex;
  background: rgb(250, 250, 250);
  justify-content: space-between;
  align-items: center;
}
.notcontent{
  width:100%;
  height:4.8rem;
}
.footcart{
  width: 100%;
  height:3rem;
  line-height: 3rem;
  position: fixed;
  bottom: 0;
  background: #45c018;
  color: white;
  font-size: 1rem;
  font-weight: 200;
}
</style>