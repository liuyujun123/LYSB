<template>
  <div class="app">
       <div class="head" >
          <span class="back1" @click="back2" >&lt;</span>
         <span class="font">比北海道梦幻，比东京便宜</span>
     </div>
       <!-- 图片 -->
       <div class="title1">
           <img src="../assets/linggan/01.png" alt="" class="first">
       </div>
       <!-- 内容一 -->
       <div class="content">
          <span class="wenzi1">比北海道梦幻，比东京便宜，这个日本小众旅行地成亲子新宠</span>
       </div>
       <!-- 内容二 -->
       <div class="content2">
          <span>在人少好玩的名古屋,藏着许多让小朋友大开眼界的好去处</span>
       </div>
       <!-- 内容三 -->
       <div class="content3">
           <div>同节假日熙熙攘攘的东京大阪相比 </div>
           <div>人少好玩的名古屋更适合家庭出游</div>
       </div>
       <!-- 图片二 -->
       <div class="title2">
           <img src="../assets/linggan/02.png" alt="" class="img1">
       </div>
       <!-- 内容四 -->
       <div class="content4">
            <span>名古屋自己不仅有历史三大名城之一的名古屋城,亚洲第二座的乐高乐园,他的周边还有童话雪乡白川乡,三大温泉之一的下吕温泉，并且它的往返机票价格比北海道、东京大阪都要便宜！
            </span>
       </div>
       <!-- 图片三 -->
       <div class="title2">
           <img src="../assets/linggan/03.png" alt="" class="img1">
       </div>
        <!-- 图片四 -->
       <div class="title2">
           <img src="../assets/linggan/01.png" alt="" class="img1" style="margin-top:30px;">
       </div>
       <!-- 内容五 -->
       <div class="content4">
            <span>
                就拿春节期间来说,国内飞到北海道的机票价格已经飙到了12000+,是名古屋的机票价格却比北海道的机票便宜小一半只有7000+,但如果您的时间不受假期约束,完全可以考虑在大年初七后出行,届时机票价格又会便宜一半,只有不到4000元！
            </span>
       </div>
       <!-- 图片四 机票价格-->
      <div class="title2">
           <img src="../assets/linggan/04.png" alt="" class="img1" >
       </div>
       <!-- 内容六  -->
       <div class="content4">
            <span>
                当然,抛却机票价格，名古屋的历史古迹、周边的系列风景对于已经去过东京、大阪甚至北海道的人来说，是一个特别不错的选择。在这里无论你是历史人文爱好者、还是寻求日式情调，感受日式美食，血拼购物，这里的古迹庭园、大须商店街、各色小吃都可以满足你。
            </span>
       </div>
       <!-- 图片五 肉 -->
       <div class="title2">
           <img src="../assets/linggan/05.png" alt="" class="img1" >
       </div>
       <!-- 内容七  -->
       <div class="content4">
            <span>
                但在这些基础上，名古屋这座城市作为一个短途目的地还有一个隐藏技能，就是特别适合带娃来一场亲子游！
            </span>
       </div>
       <!-- 图片五 海豚 -->
       <div class="title2">
           <img src="../assets/linggan/06.png" alt="" class="img1" >
       </div>
       <!-- 内容八    -->
       <div class="content4">
            <span>
              就拿大家熟知的乐高乐园来说，名古屋是亚洲的第二家，而它的动物园也曾堪称亚洲第一，小朋友都喜欢的水族馆更是日本最大的水族馆，除此之外还有世界上除美国外的第一家波音787展馆。相比于东京、大阪来说，科技的、自然的、游乐互动的，它真的是一应俱全！
            </span>
       </div>
        <!-- 图片六 旅行顾问 -->
       <div class="title2">
           <img src="../assets/linggan/07.png" alt="" class="img1" >
       </div>
       <!--  乐高乐园 -->
       <div class="biaoti">
           <h3 class="biaoti1">乐高乐园</h3>
       </div>
          <!-- 乐高乐园 内容一    -->
       <div class="content4">
            <span>
             名古屋的乐高乐园是全球第八个，亚洲的第二座乐高主题乐园。这里面充满惊喜，就像是一个奇幻的世界打开了小朋友好奇的心扉。这里面一共有7个区域，有乐高工厂、乐高city、迷你乐园、海盗海岸和冒险乐园等。
            </span>
       </div>
         <!-- 图片一 乐高 -->
       <div class="title2">
           <img src="../assets/linggan/08.png" alt="" class="img1" >
       </div>
         <!-- 乐高乐园 内容二    -->
       <div class="content4">
            <span>
              在这里小朋友可以考取驾照，探险古代遗迹，骑飞龙绕城堡飞行，或是去MINILAND看1000多万个乐高积木搭建的日本著名城市，尽情享受新鲜体验与兴奋刺激的感觉。
            </span>
       </div>
        <!-- 图片二 乐高 -->
       <div class="title2">
           <img src="../assets/linggan/09.png" alt="" class="img1" >
       </div>
       <!-- 图片三 乐高 -->
        <div class="title2">
           <img src="../assets/linggan/010.png" alt="" class="img1" style="margin-top:30px;">
       </div>
         <!-- 乐高乐园 内容三    -->
       <div class="content4">
            <span>
              当然，乐高内的乐高元素还不止这些，就连餐厅的桌子上也有乐高的白色涂鸦纸张，可以让小朋友张开想象的翅膀，在等餐的时候尽情涂鸦，而且餐厅内的乐高积木三明治既可爱又好吃，分分钟取得小朋友的欢心。
            </span>
       </div>
       <!-- 图片四 乐高 -->
        <div class="title2">
           <img src="../assets/linggan/011.png" alt="" class="img1" >
       </div>
     <!-- 名古屋港水族馆 -->
      <div class="biaoti">
           <h3 class="biaoti1">名古屋港水族馆</h3>
       </div>
       <!-- 水族馆 内容一 -->
        <div class="content4">
            <span>
             除了乐园，小朋友最喜欢的水族馆在名古屋也可以找到。而且可不是一般的水族馆哦，他是日本面积最大的水族馆，听起来就很炫酷！
            </span>
       </div>
         <!--  水族馆  图片一-->
        <div class="title2">
           <img src="../assets/linggan/012.png" alt="" class="img1" >
       </div>
       <!-- 水族馆 内容二 -->
        <div class="content4">
            <span>
             这个水族馆一共分为南馆和北馆，在南馆一共有"日本之海""深海走廊""澳大利亚之畔""赤道之海""南极之海"五个主题，于是在这里可以看到五彩斑斓的珊瑚、南极的企鹅、大片壮观的鱼群、深海的奇妙生物和畅游的海归。
            </span>
       </div>
         <!--  水族馆  图片二-->
        <div class="title2">
           <img src="../assets/linggan/013.png" alt="" class="img1" >
       </div>
        <!--  水族馆  图片三-->
        <div class="title2">
           <img src="../assets/linggan/014.png" alt="" class="img1" style="margin-top:20px;">
       </div>
        <!-- 水族馆 内容三 -->
        <div class="content4">
            <span>
             而北馆展示的主题为"35亿年的遥远旅途，再次回归大海的动物们"。在这里可以感受到处于海洋生态系统顶端的逆戟鲸的强大气场，看到淘气任性的海豚表演。
            </span>
       </div>
        <!--  水族馆  图片四-->
        <div class="title2">
           <img src="../assets/linggan/015.png" alt="" class="img1">
       </div>
        <!-- 水族馆 内容四 -->
        <div class="content4">
            <span>
             除了可以看到这些可爱的海洋生物外，水族馆内的诸多骨骼标本展现了海豚、虎鲸以及白鲸的演化过程，还可以让小朋友亲自开蚌取珍珠，总之每一个项目都会让小朋友充分的融入海洋世界，大开眼界。
            </span>
       </div>
         <!--  水族馆  图片五-->
        <div class="title2">
           <img src="../assets/linggan/016.png" alt="" class="img1">
       </div>
       <!-- 东山动植物园 -->
      <div class="biaoti">
           <h3 class="biaoti1">东山动植物园</h3>
       </div>
       <!-- 东山动植物园 内容一 -->
        <div class="content4">
            <span>
              名古屋的东山动植物园可是深受日本人都喜欢，每到周末，好多家长都会带着小朋友来到这里享受惬意的亲子时光。
            </span>
       </div>
        <!--  东山动植物园 图片一-->
        <div class="title2">
           <img src="../assets/linggan/017.png" alt="" class="img1">
       </div>
       <!-- 东山动植物园 内容二 -->
        <div class="content4">
            <span>
              这个动物园可谓历史悠久，它于1937年开园，在刚开园的时候有“亚洲第一的动物园”的美称，虽然这么多年过去，“第一”已经谈不上了，但是他的热度可是依旧不减。
            </span>
       </div>
         <!--  东山动植物园 图片二-->
        <div class="title2">
           <img src="../assets/linggan/018.png" alt="" class="img1">
       </div>
        <!--  东山动植物园 图片三-->
        <div class="title2">
           <img src="../assets/linggan/019.png" alt="" class="img1" style="margin-top:20px;">
       </div>
         <!-- 东山动植物园 内容三 -->
        <div class="content4">
            <span>
             来到这里小朋友可以看到动物园的镇园之宝“世界上最帅”的大猩猩；看到具有超高人气备受小朋友欢迎的考拉，除此之外，他们还可以体验和山羊的基础互动，喂食小动物等。
            </span>
       </div>
          <!--  东山动植物园 图片四-->
        <div class="title2">
           <img src="../assets/linggan/020.png" alt="" class="img1">
       </div>
        <!--  东山动植物园 图片五-->
        <div class="title2">
           <img src="../assets/linggan/021.png" alt="" class="img1" style="margin-top:20px;">
       </div>
        <!-- 东山动植物园 内容三 -->
        <div class="content4">
            <span>
             看完了动物当然要去看看千奇百态的植物，带着小朋友走进植物园区内现存日本最古老的温室“前馆”，欣赏约7万多种的植物，看漂亮的蔷薇园、樱花园、梅园、仙人掌等。
            </span>
       </div>
        <!--  东山动植物园 图片六-->
        <div class="title2">
           <img src="../assets/linggan/022.png" alt="" class="img1">
       </div>
        <!--  东山动植物园 图片七-->
        <div class="title2">
           <img src="../assets/linggan/023.png" alt="" class="img1" style="margin-top:20px;">
       </div>
       <!--  东山动植物园 图片八-->
        <div class="title2">
           <img src="../assets/linggan/024.png" alt="" class="img1" style="margin-top:20px;">
       </div>
        <!-- 东山动植物园 内容四 -->
        <div class="content4">
            <span>
             不过这里除了植物，庭院的设计也十分别致，就连世界遗产的白川乡的合掌屋在这里也可以看到。可以说不用驱车前往白川乡，就可以把一个个尖顶的童话小屋尽收眼底，让小朋友沉浸在动植物的天然野趣的同时，又能深切的感受日本的特色建筑文化。
            </span>
       </div>
       <!--  东山动植物园 图片九-->
        <div class="title2">
           <img src="../assets/linggan/025.png" alt="" class="img1" >
       </div>
          <!-- 丰田汽车博物馆 -->
      <div class="biaoti">
           <h3 class="biaoti1">丰田汽车博物馆</h3>
       </div>
       <!-- 丰田汽车博物馆 内容一 -->
        <div class="content4">
            <span>
              丰田汽车于近年在日本许多城市都开放了博物馆，里面展览了诸多精品古董汽车，蕴藏着汽车发明至今的许多汽车文化。所以在名古屋这里特别适合带喜欢汽车的小朋友前来。
            </span>
       </div>
        <!--  东山动植物园 图片一-->
        <div class="title2">
           <img src="../assets/linggan/026.png" alt="" class="img1" >
       </div>
       <!-- 丰田汽车博物馆 内容二 -->
       <div class="content4">
            <span>
             这家博物馆自1989年开始运营，展出了不到130辆的馆藏古董。其中有被誉为“世界第一辆汽车”的奔驰三轮车复制品和曾经被拍卖出1800万天价的劳斯莱斯银魅。
            </span>
       </div>
       <!--  东山动植物园 图片二-->
        <div class="title2">
           <img src="../assets/linggan/027.png" alt="" class="img1" >
       </div>
        <!-- 丰田汽车博物馆 内容二 -->
       <div class="content4">
            <span>
             曾属于曾经的美国总统罗斯福的帕卡德、出现在《名侦探柯南》中黑衣人的御用座驾银色保时捷也都在这家博物馆内，当喜欢汽车的小朋友看到这些充满怀旧风、历史感满满的汽车前，肯定既开心又难忘。
            </span>
       </div>
         <!--  东山动植物园 图片三-->
        <div class="title2">
           <img src="../assets/linggan/028.png" alt="" class="img1" >
       </div>
       <!--  东山动植物园 图片四-->
        <div class="title2">
           <img src="../assets/linggan/029.png" alt="" class="img1" style="margin-top:30px;">
       </div>
           <!-- 名古屋机场 -->
      <div class="biaoti">
           <h3 class="biaoti1">名古屋机场Fight Of Dreams</h3>
       </div>
       <!-- 名古屋机场 内容一 -->
       <div class="content4">
            <span>
           Fight Of Dreams是去年底在名古屋刚刚开幕的波音787展览馆，它是除了美国之外，在全球第一家公开展示波音787的地方，虽然一架787的真机就已经足够吸睛，但这里更多的酷炫体验可是比这辆飞机还吸引人！
            </span>
       </div>
         <!--  名古屋机场 图片一-->
        <div class="title2">
           <img src="../assets/linggan/030.png" alt="" class="img1" >
       </div>
       <!--  名古屋机场 图片二-->
        <div class="title2">
           <img src="../assets/linggan/031.png" alt="" class="img1" style="margin-top:20px;">
       </div>
        <!-- 名古屋机场 内容二 -->
       <div class="content4">
            <span>
          在这里，小朋友可以了解飞机的组装过程，用趣味的方式学习航空知识，并且每隔30分钟就会欣赏到一场长达8分钟的绚丽灯光秀，体验光影从不同的角度打在飞机上的另一种美感。
            </span>
       </div>
         <!--  名古屋机场 图片二-->
        <div class="title2">
           <img src="../assets/linggan/032.png" alt="" class="img1" >
       </div>
        <!-- 名古屋机场 内容三 -->
       <div class="content4">
            <span>
          除了这场科技感十足的灯光秀，小朋友还可以动手折纸飞机，然后再将自己的作品掷向光线大门。随着每一只纸飞机在光影中的飞行轨迹、远近的不同，小朋友也会对飞行原理产生兴趣，在快乐玩耍的同时提升对事物的思考能力。
            </span>
       </div>
         <!--  名古屋机场 图片三-->
        <div class="title2">
           <img src="../assets/linggan/033.png" alt="" class="img1" >
       </div>
       <!--  名古屋机场 图片四-->
        <div class="title2">
           <img src="../assets/linggan/034.png" alt="" class="img1" style="margin-top:20px;">
       </div>
       <!-- 名古屋机场 内容四 -->
       <div class="content4">
            <span>
          不过这还不够，在场馆内令小朋友激动地重头戏就是进入驾驶舱，在指导员的帮助下模拟驾驶飞机，体验一把充满挑战的驾驶。总之，就这些项目，别说小孩子，就连大人也会想雀雀欲试呢！
            </span>
       </div>
           <!--  名古屋机场 图片五-->
        <div class="title2">
           <img src="../assets/linggan/035.png" alt="" class="img1" >
       </div>
       <!--  名古屋机场 图片六-->
        <div class="title2">
           <img src="../assets/linggan/036.png" alt="" class="img1" style="margin-top:20px;">
       </div>
          <!-- 白鸟庭院 -->
      <div class="biaoti">
           <h3 class="biaoti1">白鸟庭院</h3>
       </div>
       <!-- 白鸟庭院 内容一 -->
       <div class="content4">
            <span>
          白鸟庭园是一座漂亮的日式庭园，它兼具传统美和现代手法，意趣十足。漫步其中，一景一隅都别具美感，十分适合一家人在此度过一个愉悦的午后。
            </span>
       </div>
       <!--  白鸟庭院 图片一  -->
        <div class="title2">
           <img src="../assets/linggan/037.png" alt="" class="img1" >
       </div>
      
        <!-- 白鸟庭院 内容一 -->
       <div class="content4">
            <span>
            走在小桥上，看涓涓流水和水面上倒映的雪吊，给小朋友买一杯鱼食，任由他们在暖阳下向湖中投食，看鱼儿抢食，水鸟欢腾。
            </span>
       </div>
        <!--  白鸟庭院 图片二  -->
        <div class="title2">
           <img src="../assets/linggan/038.png" alt="" class="img1" >
       </div>
       <!-- 白鸟庭院 内容一 -->
       <div class="content4">
            <span>
            这里春有樱花，夏日翠绿，当秋日来临，园中又成了赏枫的圣地，看着造景的小山，竹林虚掩，听一听那些德川桥、丰臣桥和织田桥名字背后各大名家的故事，走累了，再去茶室饮一杯清茶，亲密的家庭时光在这个小小庭园中尤为美好。
            </span>
       </div>
        <!--  白鸟庭院 图片二  -->
        <div class="title2">
           <img src="../assets/linggan/039.png" alt="" class="img1" >
       </div>
       <!--  白鸟庭院 图片三  -->
        <div class="title2">
           <img src="../assets/linggan/040.png" alt="" class="img1" style="margin-top:30px;" >
       </div>
       <!-- 底部 内容 -->
       <div class="end1">
         <span>拨打电话<font style="color:green"> 400-010-6003 </font>免费咨询旅游顾问</span>
       </div>
       <!-- 底部 -->
       <div class="endd1" fixed>
         <button @click="Bback">咨询 日本 名古屋亲子 的行程</button>
       </div>

    

  </div>

  
</template>

<script>
export default {
  data(){
    return{
        list:[]
    }
  },
   methods:{
      Bback(){
             this.$router.go(-1);
      },
      back2(){
             this.$router.push("/");
      },
       loadMore(){
            //console.log(123);
            //发送请求获取购物车数据
            //1：创建变量url保存请求服务器程序地址
            var url="area";
            //2：发送ajax请求并且获取服务器返回数据
            this.axios.get(url).then(res=>{
              var rows=this.list.concat(res.data.data);
                       this.list=rows;
                     console.log(this.list)
            })
        }
  }
}
</script>


<style  scoped>
*{margin:0;padding:0;}
.app{
   display: flex; /*弹性布局*/
  flex-wrap: wrap; /*子元素换行*/
  overflow: hidden; /*溢出隐藏*/
    overflow: auto; 
    
}
  .head{
      display:flex;   /* 指定布局方式:弹性布局 */
       position: fixed; /*  固定定位 */
      z-index:999;   /*  显示元素上方 */
      width:100%;  /*  填满父元素 */
     align-items: center;  /*   子元素垂直居中 */
     background-color: #fff;
     padding-left:7px;
     padding-right:7px;
     height:48px;
     color:#000;
     font-size:18px;
     border-bottom:0.5px solid #e8e8e8;
  }
   .back1{
   position: absolute;
   padding-left:3%; 
  }
  .font{
   width:100%;
   text-align: center;
  }
  .title1{
      width:100%;
      margin:0px;
      padding:0px;
  }
 .first{
     margin:0px;
     padding:0px;
     width:100%;
     margin-top:48px; 
 }
 .content{
      color:#353434;
      width:100%;
      padding: 3%;
      font-size: 20px;
         text-align:justify; 
   text-justify:inter-ideograph;
    
 }
 .content2{
     background-color:#fdf6f6; 
     color:#b6b3b3;
   width:90%;
   margin: 3%;
   padding: 3%;
   font-size: 15px;
    text-align:justify; 
   text-justify:inter-ideograph;
 }
 .content3{
      padding: 8%;
      width: 60%;
      margin-left:13%;
      text-align: center;
      line-height: 25px;
       color: #7a7373;
      
 }
  .title2{
      width: 90%;
      justify-content:center;
      
  }
  .img1{
      margin-left:5.5%; 
      width: 100%;
      border-radius:8px; 
  }
  .content4{
    width:90%;
   margin: 3%;
   padding: 3%;
   letter-spacing:1px;
   line-height: 28px;
   text-align:justify; 
   text-justify:inter-ideograph;
   color: #7a7373
  }
  .title2{
      width: 90%;
      justify-content:center;
  }
  .biaoti{
    width: 100%;
    text-align: center;
    margin-top:30px;
  }
 .end1{
   font-size:8px;
   color:#7a7373;
   margin-bottom:80px; 
   margin-left: 3%;
   padding-left: 3%;
 }
 .endd1{
   width:100%;
     margin:0px;
   margin-left:15%;

 }
 .endd1 button{
   height:48px;
    background: #7cdf81;
    border-radius: 5px;
    color:#fff;
   border:none;

 position: fixed;

bottom: 0;
right: 2.5%;
font-size: 15px;
background-color: #7cdf81;
width:95%;

 }
 
</style>