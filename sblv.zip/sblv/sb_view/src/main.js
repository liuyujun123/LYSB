import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
//引入和配置mint-ui组件库
import MintUI from "mint-ui"
import "mint-ui/lib/style.css"
Vue.use(MintUI)
//引入和配置element-ui组件库
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI)
// 引入 c-swipe 主文件
import 'c-swipe/dist/swipe.css';
import { Swipe, SwipeItem } from 'c-swipe';
Vue.component('swipe', Swipe);
Vue.component('swipe-item', SwipeItem);
//引入字体图标文件
import "@/assets/font/iconfont.css"
import "@/assets/font1/iconfont.css"
//引入axios库
import axios from "axios"
axios.defaults.baseURL="http://127.0.0.1:5050/"
axios.defaults.withCredentials=true
Vue.prototype.axios = axios

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
